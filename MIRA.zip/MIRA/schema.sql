-- ============================================================================
-- Mira — Personal AI Accountant — MySQL schema
-- ============================================================================
-- Run this once in phpMyAdmin / mysql CLI inside your XAMPP MySQL instance.
-- ============================================================================

CREATE DATABASE IF NOT EXISTS `mira`
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE `mira`;

-- ---------------------------------------------------------------------------
-- users
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id`                  INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `email`               VARCHAR(190)    NOT NULL,
  `password_hash`       VARCHAR(255)    NOT NULL,
  `name`                VARCHAR(120)    NOT NULL,
  `locale`              ENUM('en','es') NOT NULL DEFAULT 'en',
  `theme`               ENUM('light','dark') NOT NULL DEFAULT 'light',
  `currency`            VARCHAR(8)      NOT NULL DEFAULT 'USD',

  -- Plan & billing
  `plan`                ENUM('free','premium') NOT NULL DEFAULT 'free',
  `stripe_customer_id`  VARCHAR(255)    NULL,
  `trial_ends_at`       DATETIME        NULL,     -- 14-day trial for new users

  `created_at`          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- expenses
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `expenses` (
  `id`              BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`         INT UNSIGNED     NOT NULL,
  `title`           VARCHAR(160)     NOT NULL,
  `amount`          DECIMAL(12, 2)   NOT NULL,
  `expense_date`    DATE             NOT NULL,
  `description`     TEXT             NULL,
  `category`        ENUM(
                      'food','transport','entertain','health',
                      'subs','shopping','home','other'
                    ) NOT NULL DEFAULT 'other',
  `ai_confidence`   DECIMAL(3, 2)    NOT NULL DEFAULT 0.00,
  `ai_categorized`  TINYINT(1)       NOT NULL DEFAULT 1,
  `recurring_id`    INT UNSIGNED     NULL,        -- FK → recurring_expenses (premium)
  `currency`        VARCHAR(8)       NOT NULL DEFAULT 'USD',  -- per-expense currency (premium)
  `amount_usd`      DECIMAL(12, 2)   NULL,        -- normalized amount (premium, for cross-currency totals)
  `created_at`      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_expenses_user_date` (`user_id`, `expense_date` DESC),
  KEY `idx_expenses_user_cat`  (`user_id`, `category`),
  CONSTRAINT `fk_expenses_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- subscriptions  [billing — managed by Stripe webhooks]
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `subscriptions` (
  `id`                      INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`                 INT UNSIGNED  NOT NULL,
  `stripe_subscription_id`  VARCHAR(255)  NOT NULL,
  `stripe_price_id`         VARCHAR(255)  NOT NULL,
  `status`  ENUM('trialing','active','past_due','canceled','unpaid') NOT NULL DEFAULT 'trialing',
  `plan`                    ENUM('monthly','annual') NOT NULL,
  `current_period_start`    DATETIME      NOT NULL,
  `current_period_end`      DATETIME      NOT NULL,
  `cancel_at_period_end`    TINYINT(1)    NOT NULL DEFAULT 0,
  `canceled_at`             DATETIME      NULL,
  `created_at`              DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`              DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_stripe_sub`  (`stripe_subscription_id`),
  KEY `idx_sub_user`          (`user_id`),
  CONSTRAINT `fk_sub_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- budgets  [PREMIUM] — monthly/weekly spending limits per category
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `budgets` (
  `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`     INT UNSIGNED  NOT NULL,
  `category`    ENUM('food','transport','entertain','health','subs','shopping','home','other') NOT NULL,
  `amount`      DECIMAL(12, 2) NOT NULL,
  `period`      ENUM('monthly','weekly') NOT NULL DEFAULT 'monthly',
  `notify_at`   TINYINT UNSIGNED NOT NULL DEFAULT 80,  -- alert when % of budget is reached (0 = off)
  `created_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_budget_user_cat_period` (`user_id`, `category`, `period`),
  CONSTRAINT `fk_budget_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- recurring_expenses  [PREMIUM] — fixed recurring bills & subscriptions
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `recurring_expenses` (
  `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`     INT UNSIGNED  NOT NULL,
  `title`       VARCHAR(160)  NOT NULL,
  `amount`      DECIMAL(12, 2) NOT NULL,
  `category`    ENUM('food','transport','entertain','health','subs','shopping','home','other') NOT NULL DEFAULT 'other',
  `frequency`   ENUM('weekly','biweekly','monthly','yearly') NOT NULL DEFAULT 'monthly',
  `next_due`    DATE          NOT NULL,
  `is_active`   TINYINT(1)    NOT NULL DEFAULT 1,
  `auto_add`    TINYINT(1)    NOT NULL DEFAULT 0,  -- if 1, expense is logged automatically on due date
  `notes`       TEXT          NULL,
  `created_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_recurring_user` (`user_id`, `is_active`),
  KEY `idx_recurring_due`  (`next_due`),
  CONSTRAINT `fk_recurring_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- savings_goals  [PREMIUM] — goal-based savings tracker
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `savings_goals` (
  `id`              INT UNSIGNED   NOT NULL AUTO_INCREMENT,
  `user_id`         INT UNSIGNED   NOT NULL,
  `title`           VARCHAR(160)   NOT NULL,
  `emoji`           VARCHAR(8)     NOT NULL DEFAULT '🎯',
  `target_amount`   DECIMAL(12, 2) NOT NULL,
  `saved_amount`    DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
  `target_date`     DATE           NULL,
  `is_completed`    TINYINT(1)     NOT NULL DEFAULT 0,
  `created_at`      DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_goals_user` (`user_id`),
  CONSTRAINT `fk_goal_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- savings_goal_contributions  [PREMIUM] — log of deposits into a goal
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `savings_goal_contributions` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `goal_id`     INT UNSIGNED    NOT NULL,
  `user_id`     INT UNSIGNED    NOT NULL,
  `amount`      DECIMAL(12, 2)  NOT NULL,
  `note`        VARCHAR(255)    NULL,
  `contributed_at` DATE         NOT NULL,
  `created_at`  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_contrib_goal` (`goal_id`),
  CONSTRAINT `fk_contrib_goal`
    FOREIGN KEY (`goal_id`) REFERENCES `savings_goals` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_contrib_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- csv_imports  [PREMIUM] — audit trail of imported files
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `csv_imports` (
  `id`              INT UNSIGNED   NOT NULL AUTO_INCREMENT,
  `user_id`         INT UNSIGNED   NOT NULL,
  `filename`        VARCHAR(255)   NOT NULL,
  `rows_imported`   SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  `rows_skipped`    SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  `status`          ENUM('pending','done','failed') NOT NULL DEFAULT 'pending',
  `error_message`   TEXT           NULL,
  `created_at`      DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_import_user` (`user_id`),
  CONSTRAINT `fk_import_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- weekly_digests  [PREMIUM] — record of sent email digests
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `weekly_digests` (
  `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`     INT UNSIGNED  NOT NULL,
  `week_start`  DATE          NOT NULL,
  `total_spent` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `top_category` VARCHAR(20)  NULL,
  `sent_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_digest_user_week` (`user_id`, `week_start`),
  CONSTRAINT `fk_digest_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- (Optional) Seed a demo user — password is "demo1234"
-- Generated via PHP: password_hash('demo1234', PASSWORD_DEFAULT)
-- ---------------------------------------------------------------------------
-- INSERT INTO `users` (email, password_hash, name)
-- VALUES ('sam@mira.app',
--         '$2y$10$RkqV0xYbVk4yHvO9oCXEZuQ7XK7T8ckPgB9wQRwZUUC1pTvSqfYey',
--         'Sam Rivera');
