# Handoff: Mira — Personal AI Accountant

## Overview

**Mira** is a personal expense-tracker SaaS with on-device AI categorization
and a friendly money-coach persona. Users add expenses manually; the app
categorizes them automatically (via a keyword-based classifier) and surfaces
weekly/monthly insights ("your subscriptions are stacking up", "you're
spending faster than last month", etc.) on a dashboard with simple charts.

The name *Mira* is Spanish for "look" — fitting for an app whose value is
showing you where your money is actually going. The UI ships bilingual
(EN/ES) with a top-bar toggle and supports light + dark mode.

---

## About the design files

The files in `prototype/` are **design references created as a high-fidelity
HTML/React prototype** — not production code to copy directly. They show the
intended look, layout, copy, and interaction patterns of every screen.

Your job is to **recreate these designs in the target stack** (see below)
using its own patterns and libraries. The HTML/JSX is a reference; the
real implementation will be in PHP + MySQL with vanilla JS on the front-end.

## Fidelity

**High-fidelity (hi-fi).** Pixel-perfect mockups with final colors,
typography, spacing, motion, and interaction states. Match the visuals
closely. Spec all design tokens are listed below.

---

## Target stack (per original brief)

- **Frontend:** HTML5, CSS3, vanilla JavaScript (no React, no Vue)
- **Backend:** Pure PHP (no Laravel/Symfony/etc.)
- **Database:** MySQL
- **Charts:** Chart.js (already used in prototype — same library)
- **Local dev:** XAMPP (Apache + PHP + MySQL on `localhost`)

If you'd rather use a modern stack (Next.js + Postgres etc.), the design
ports cleanly — but the brief was explicit about plain PHP, so default to
that unless instructed otherwise.

## Suggested file structure

```
mira/
├── public/                       ← Apache document root
│   ├── index.php                 ← router / front controller
│   ├── login.php
│   ├── register.php
│   ├── logout.php
│   ├── dashboard.php
│   ├── expenses.php
│   ├── insights.php
│   ├── categories.php
│   ├── category.php?slug=food
│   ├── settings.php
│   ├── assets/
│   │   ├── css/styles.css        ← port of prototype/styles.css
│   │   ├── js/app.js             ← vanilla JS (add-expense modal, search…)
│   │   ├── js/charts.js          ← Chart.js setup
│   │   └── js/i18n.js            ← EN/ES strings (port of I18N from data.js)
│   └── api/
│       ├── expenses_create.php   ← POST: { title, amount, date, desc }
│       ├── expenses_list.php     ← GET:  ?period=&category=&q=
│       ├── expenses_delete.php
│       ├── categorize.php        ← POST: { title, desc } → live AI preview
│       └── insights.php          ← GET → JSON array of insight cards
├── includes/
│   ├── db.php                    ← PDO singleton, prepared-statement helper
│   ├── auth.php                  ← session start, require_login(), CSRF
│   ├── Categorizer.php           ← ← see backend_reference/Categorizer.php
│   ├── InsightsEngine.php        ← see "AI Insights" section below
│   └── helpers.php               ← formatMoney(), formatDate(), etc.
├── config/
│   └── db.php                    ← DB credentials (NOT committed)
└── schema.sql                    ← see ./schema.sql
```

---

## Screens

There are **7 screens** in the design. Each lives as a top-level route.

### 1. Auth (Login / Register)

**File reference:** `AuthView` in `prototype/views.jsx`

- **Layout:** Two-column split, 50/50.
  - **Left (form side):** Centered form, max-width 420px.
  - **Right (illustration side):** Full-bleed violet gradient with quote
    + two decorative mock-cards floating at offset angles.
  - Below 980px → form side becomes full width, illustration hidden.
- **Form fields (sign in):** Email, Password. Submit button is full-width.
- **Form fields (sign up):** Name, Email, Password.
- **"Continue with Google"** button is decorative (outline style); below it
  a divider with "or"/"o".
- **Mode toggle** at the bottom: "Don't have an account? Create account" /
  "Already have an account? Sign in".
- **Top-right of left side:** language toggle (EN/ES) + theme toggle (sun/moon).
- **Right side quote:** Localized fake testimonial — replace with a real
  one or remove for v1.
- **On submit:** Set PHP session, redirect to `/dashboard.php`. No real
  validation in v1 beyond presence + email format + `password_verify()`.

### 2. Dashboard

**File reference:** `DashboardView` in `prototype/views.jsx`

The main landing page after sign-in. Layout from top to bottom:

1. **AI summary card** (violet-tinted hero). Avatar + "Mira" label + AI badge
   + 1–2-sentence summary. Body text is generated server-side and pulled
   from `InsightsEngine::summary($expenses, $lang)` — see below.

2. **Stat row** — 4 columns:
   - **Spent this month** — feature card, violet gradient background, with
     decorative blurred circle in the top-right corner. Shows total + delta
     vs. last month pill.
   - **Transactions** — count this month + count last month.
   - **Avg per day** — `total / dayOfMonth`.
   - **Top category** — name + chip + amount.
   - Collapses to 2-col below 980px.

3. **By category card + Top category card** — 2/3 + 1/3 grid.
   - "By category" shows a **donut** OR **bars** chart (user-selectable —
     for now hard-code donut). Under the chart, top 5 categories listed
     as horizontal progress bars with category color, percentage of total,
     and amount. Each row clicks through to `/category.php?slug={cat}`.
   - "Top category" shows the leading category with its colored icon tile,
     amount, and 3 most-recent expenses in it.

4. **Monthly trend card** — full-width bar chart, last 6 months totals.

5. **Recent expenses card** — 6 most recent expenses (across all dates) as
   list rows. "See all" link → `/expenses.php`.

### 3. Expenses list

**File reference:** `ExpensesView` in `prototype/views.jsx`

- **Filter card** at top:
  - **Search input** (icon prefix). Filters by title + description (case-
    insensitive substring).
  - **Period segmented control:** This month / Last month / Last 3 months
    / All time.
  - **Category pills** row — "All" + one pill per category that has any
    expense. Shows category color dot + label + `·count`. Active pill is
    filled violet.
- **Results bar:** "N results" + total amount.
- **Expense list:** Each row = `[color tile w/ icon] [title + category chip
  + description] [amount] [date]`. Hover lightens row background.
- **Empty state:** Magnifier icon + "No expenses match those filters."

### 4. Insights

**File reference:** `InsightsView` in `prototype/views.jsx`

- Max width 760px, centered.
- AI summary hero card (same style as dashboard's).
- A stack of **insight cards**, each:
  - 36×36 icon tile (left)
  - Title (semibold) + body (muted, 13px)
  - Tone variant by border color: coach (violet), warn (red border), win
    (green border), neutral (default border).
- Cards fade-in with staggered 60ms delay.
- Insight generation is described in **AI Insights** section below.

### 5. Categories (grid)

**File reference:** `CategoriesView` in `prototype/views.jsx`

- Responsive auto-fill grid, min column width 220px.
- One card per category (all 8 always shown, even if zero):
  - 44×44 colored icon tile
  - Transaction count chip (top-right)
  - Category name
  - Amount this month (large, semibold)
  - "X% of month" caption
  - Tiny progress bar in the category color
- Click → category detail screen.

### 6. Category detail

**File reference:** `CategoryDetailView` in `prototype/views.jsx`

- **Back button** (← Back to categories) top-left.
- **Header card:** 64×64 category icon + "Category" label + name as h1.
- **Stat row:** This month / Monthly average / Transactions / Highest
  single expense.
- **All expenses card:** Full list of expenses in this category, sorted
  by date desc.

### 7. Settings

**File reference:** `SettingsView` in `prototype/views.jsx`

- **Profile card:** Large avatar + name/email + editable Name + Email fields.
- **Appearance card:** Dark mode toggle (switch) + Language segmented (EN/ES).
- **Danger zone card** (red-tinted border): "Reset to demo data" button —
  in production this would be "Delete all my expenses" with a confirm modal.

### 8. Add Expense modal (overlay)

**File reference:** `AddExpenseModal` in `prototype/views.jsx`

- Triggered by **"+ Add expense"** button in the top bar from any screen
  except Settings.
- Modal width 520px, centered, fade-in + pop-in spring.
- **Fields:** Title (autofocus), Amount (with `$` prefix), Date (today by
  default), Description (textarea, optional).
- **AI suggestion strip** (always visible at the bottom of the form):
  - When empty: violet sparkle avatar + "Type a title and I'll categorize
    it..."
  - When the title has content: colored icon for the suggested category +
    "AI SUGGESTS" label + category name. To the right: up to 2 alternative
    category chips the user can click to override the AI's pick.
  - The categorization is **live** — runs on every keystroke. In the
    prototype this is client-side JS; in the real app, call
    `/api/categorize.php` on `input` debounced ~150ms.
- **Footer:** Cancel (ghost) + Save expense (primary, with check icon).
  Save is disabled until title + amount are present.
- **On save:** POST to `/api/expenses_create.php`, close modal, refresh
  the current view's data.

---

## Design tokens

### Colors — light theme

| Token              | Hex / value          | Usage                          |
|--------------------|----------------------|--------------------------------|
| `--violet-50`      | `#F4F0FF`            | Subtle violet tints, AI bg     |
| `--violet-100`     | `#E8E0FF`            | Hover wash                     |
| `--violet-200`     | `#D4C4FF`            | Borders on AI cards            |
| `--violet-300`     | `#B49DFF`            | Dashed borders, secondary      |
| `--violet-400`     | `#8E6CFA`            | Logo gradient mid              |
| `--violet-500`     | `#6C4CF2`            | **Primary brand**              |
| `--violet-600`     | `#5A3DD9`            | Primary hover                  |
| `--violet-700`     | `#4A2EB8`            | Primary pressed, dark accents  |
| `--bg`             | `#FBFAFC`            | Page background                |
| `--bg-elev`        | `#FFFFFF`            | Cards, modals, inputs          |
| `--bg-soft`        | `#F5F2FB`            | Hover wash, chip bg            |
| `--bg-softer`      | `#FAF8FE`            | Row-hover background           |
| `--border`         | `#ECECF2`            | Card + input borders           |
| `--border-strong`  | `#DCDAE6`            | Input border (resting)         |
| `--text`           | `#1A1726`            | Primary text                   |
| `--text-muted`     | `#6B6880`            | Secondary text                 |
| `--text-faint`     | `#A6A2B8`            | Dates, hints                   |

### Colors — dark theme

| Token              | Hex / value          |
|--------------------|----------------------|
| `--bg`             | `#0E0B1A`            |
| `--bg-elev`        | `#18142A`            |
| `--bg-soft`        | `#1F1A36`            |
| `--bg-softer`      | `#15112A`            |
| `--border`         | `#2A2440`            |
| `--border-strong`  | `#3A335A`            |
| `--text`           | `#F2F0FA`            |
| `--text-muted`     | `#9C99B5`            |
| `--text-faint`     | `#6B6790`            |
| `--violet-50`      | `#251D45`            |
| `--violet-100`     | `#2E2452`            |

Switch by setting `data-theme="dark"` on `<html>`.

### Category colors

| Slug         | Color        | Hex        | EN label           | ES label              |
|--------------|--------------|------------|--------------------|-----------------------|
| `food`       | coral red    | `#F97373`  | Food & Drink       | Comida y bebida       |
| `transport`  | sky blue     | `#5A9DF2`  | Transport          | Transporte            |
| `entertain`  | warm amber   | `#F2A93B`  | Entertainment      | Entretenimiento       |
| `health`     | mint teal    | `#4ECDC4`  | Health             | Salud                 |
| `subs`       | lavender     | `#B47BE8`  | Subscriptions      | Suscripciones         |
| `shopping`   | soft pink    | `#F586C4`  | Shopping           | Compras               |
| `home`       | sage green   | `#7AC97A`  | Home & Bills       | Hogar y servicios     |
| `other`      | neutral gray | `#9CA3AF`  | Other              | Otros                 |

### Typography

- **Sans:** `"Geist", "Plus Jakarta Sans", system-ui, sans-serif`
- **Mono (for amounts):** `"Geist Mono", "JetBrains Mono", monospace`
- Body: 15px / 1.5, letter-spacing `-0.005em`, antialiased.
- Headings:
  - h1 — 28px / 600 / `-0.02em`
  - h2 — 20px / 600 / `-0.015em`
  - h3 — 16px / 600 / `-0.01em`
  - Stat values — 28px / 600 / `-0.02em`, tabular-nums.
  - Auth title — 30px / 600 / `-0.02em`.
- Small / caption — 12–13px, `--text-muted`.

Load Geist + Geist Mono from Google Fonts:
```html
<link rel="stylesheet"
  href="https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600;700&family=Geist+Mono:wght@400;500&display=swap" />
```

### Radii

| Token       | px   | Used for                                 |
|-------------|------|------------------------------------------|
| `--r-xs`    | 8    | Chips, small buttons                     |
| `--r-sm`    | 12   | Inputs, nav items, small cards           |
| `--r-md`    | 16   | Cards, modals, primary surfaces          |
| `--r-lg`    | 20   | Modal corners, hero illustrations        |
| `--r-xl`    | 28   | (Reserved — not currently used)          |
| `--r-pill`  | 999  | Pills, chips, progress bars, switch      |

### Shadows

| Token         | Value (light theme)                                                 |
|---------------|---------------------------------------------------------------------|
| `--shadow-sm` | `0 1px 2px rgba(28,20,60,.04), 0 1px 3px rgba(28,20,60,.03)`        |
| `--shadow-md` | `0 2px 4px rgba(28,20,60,.04), 0 8px 24px rgba(28,20,60,.06)`       |
| `--shadow-lg` | `0 8px 32px rgba(28,20,60,.12), 0 2px 8px rgba(28,20,60,.06)`       |

(Dark theme uses denser opacities — see `styles.css`.)

### Spacing

Steps: 4, 8, 12, 16, 20, 24, 32, 40, 48 (`--s-1` through `--s-12`).
Most card padding is 18–20px. Content padding is 28–32px desktop,
14–16px mobile. Gaps between cards: 16–20px.

### Motion

- **Standard easing:** `cubic-bezier(0.4, 0, 0.2, 1)` (Material-ish).
- **Spring easing:** `cubic-bezier(0.34, 1.56, 0.64, 1)` for modal pop-in
  and toggle thumb.
- Hover transitions: 150ms. Theme transitions: 200ms.
- Chart animation: Chart.js defaults are fine.
- `.fade-in` keyframe on view mount: `slideUp 280ms ease both` (8px up
  + opacity).

---

## Interactions & behavior

- **Sidebar nav:** Active item gets `is-active` class — violet-50 bg,
  violet-600 text. Hovers get `bg-soft`. Sidebar is `position: sticky;
  top: 0; height: 100vh;` — does not scroll with content.
- **Top bar:** Sticky, blurred background. Shows current screen title +
  subtitle, language + theme toggles, notification bell (decorative for
  v1), and "+ Add expense" button (hidden on Settings).
- **Add expense modal:** Backdrop click closes. Esc key should also close
  (add a `keydown` listener). Autofocus the title input. Save is disabled
  while title or amount are empty.
- **Live AI categorization:** As user types in title or description, call
  `/api/categorize.php` with debounce ~150ms. Update the suggestion strip
  in place; if alternatives come back, render them as chips the user can
  click to override (sets a local "overrideCat" that wins until the user
  types again).
- **Search debounce:** On the Expenses page, debounce the search input
  ~120ms before re-filtering. If filtering server-side, fetch on the
  debounce; if client-side (recommended for typical usage volumes),
  filter in memory.
- **Theme & language persistence:** Store on the `users` row (`theme`,
  `locale` columns in the schema). Also write to a cookie so the auth
  page can read it before session is open.
- **Logout:** Sidebar footer has an exit icon → `/logout.php` which
  destroys the session and redirects to `/login.php`.

### Responsive

Single breakpoint at **980px**:
- Below 980px: sidebar hidden (replace with a hamburger drawer if you
  want — not in the prototype), stat row 2-col, dashboard grid 1-col,
  auth illustration hidden.
- Mobile content padding: 14–16px instead of 28–32px.

Modal width: `min(520px, calc(100vw - 32px))`.

---

## AI Categorizer

The categorizer is a **keyword scoring function**, not an ML model.
Direct PHP port is in `backend_reference/Categorizer.php` (drop into
`includes/`). Same keyword lists as the prototype's `data.js`.

**Algorithm:**
1. Lowercase + trim the combined `"<title> <description>"`.
2. For each category, sum scores: every keyword in that category's list
   that appears as a substring contributes `max(1, floor(strlen(kw)/3))`.
   Longer/more specific keywords beat short generic ones.
3. The highest-scoring category wins. If all zero → `other`.
4. Confidence = `min(0.99, 0.5 + (topScore / max(total, topScore)) * 0.5)`.
   It's a soft signal — only used in UI badges.
5. Alternatives = next 3 categories with non-zero scores, for the user
   to override.

**Return shape:**
```php
['category' => 'transport', 'confidence' => 0.92, 'alternatives' => ['food']]
```

**API endpoint:** `POST /api/categorize.php` with `{ title, description }`
returning the same JSON shape. Used by the Add Expense modal for live
preview. Also called server-side on `expenses_create.php` to set the
final stored category + confidence (unless the user overrode it).

**Storing user overrides:** When the user clicks an alternative chip in
the modal, send the chosen category along with the create request, and
set `ai_categorized = 0` in the DB. Useful for future keyword tuning.

---

## AI Insights

Insights are **rule-based**, computed server-side from the user's expense
totals. Each rule returns 0 or 1 insight card. Cards are ordered by
priority. There is no LLM call — it's all math.

Implement as `includes/InsightsEngine.php` with one method:
`InsightsEngine::generate(array $expenses, string $lang): array`. Each
returned item has:

```php
[
  'tone' => 'coach' | 'warn' | 'win' | 'neutral',
  'title' => '...',         // already localized
  'body' => '...',          // already localized
  'icon' => 'trophy' | 'arrow-up' | 'tv' | 'trending-up' | 'trending-down' | 'sparkle' | 'calendar',
  'cat' => 'food',          // optional — tints the icon tile in the cat's color
]
```

### Rules (in order of priority)

Reference JS implementation in `data.js → generateInsights()`. Ports
straight to PHP.

1. **Welcome (empty state)** — fires only when `count(expenses) === 0`.
   Tone neutral. "Welcome to Mira! Add your first few expenses…"

2. **Top category callout** — always fires when there's any data.
   Tone coach. Title: "{Category} is your biggest spend".
   Body: "You've put {amt} into {cat} — that's {pct}% of this month."

3. **Category spike (month-over-month)** — for any category where
   `thisMonth > 1.3 × lastMonth` AND `thisMonth − lastMonth > 30`.
   Only fires for the first matching category. Tone warn.
   "Heads up: {Category} jumped" / "Spending in {cat} is up {pct}% vs
   last month (+${diff})."

4. **Subscription overload** — fires when `subs > 0.2 × totalThisMonth`.
   Tone warn. "Subscriptions are stacking up" / "You're paying {amt} in
   subscriptions this month. Want to audit them together?"

5. **Win** — for any category where `lastMonth > 40` AND `thisMonth <
   0.7 × lastMonth`. Tone win. "Nice work on {Category} 🎉" / "You cut
   {cat} by {amt} compared to last month."

6. **Pace nudge** — compares total this-month-so-far vs total last-month.
   If `this > 1.15 × last` → warn ("You're spending faster"). If `this <
   0.85 × last` → win ("Slower month, well done").

7. **End-of-month projection** — fires when `day >= 5`. Tone neutral.
   "Averaging {avg}/day. If you keep this pace you'll close the month
   around {proj}." (`proj = avgPerDay × daysInMonth`)

### Dashboard summary (one-liner above the stats)

Different method: `InsightsEngine::summary($expenses, $lang)` returns a
single sentence used in the violet hero card on the dashboard. Template:

> *"You've spent **{total}** so far this month — **{cat}** is leading at
> **{catAmt}**. At this pace you'll land around **{proj}**. Let's keep
> that in check 💪"*

Spanish version is in `data.js → I18N.es.aiSumLine`.

All copy strings (titles + bodies) for both languages are in the `I18N`
object of the prototype's `data.js`. Port to a PHP array keyed by language
code, used by both the categorizer and the insights engine.

---

## i18n

**Two languages: `en` (default) and `es`.** The full string table is in
`prototype/data.js` under the `I18N` constant — copy verbatim into a PHP
array (`includes/i18n.php`) and use a helper:

```php
function t(string $key, array $vars = []): string {
    $lang = $_SESSION['lang'] ?? 'en';
    $val = LANG_STRINGS[$lang][$key] ?? LANG_STRINGS['en'][$key] ?? $key;
    foreach ($vars as $k => $v) $val = str_replace('{' . $k . '}', $v, $val);
    return $val;
}
```

**Format helpers** (also in `data.js`):
- `formatMoney(n)` → `"$1,234.56"`. Uses `Intl.NumberFormat("en-US",
  { minimumFractionDigits: 2, maximumFractionDigits: 2 })`. In PHP:
  `'$' . number_format($n, 2, '.', ',')`.
- `formatDate(d)` → `"Nov 12"` (EN) / `"12 nov"` (ES). Use
  `IntlDateFormatter` or hand-roll with `strftime`.

---

## Theme switching

Single `data-theme` attribute on `<html>`, value `"light"` or `"dark"`.
All theming is via CSS custom properties — no `prefers-color-scheme`
listener in v1; user controls it explicitly.

```js
// public/assets/js/app.js
document.documentElement.setAttribute('data-theme', userTheme);
// Persist via fetch('/api/settings_save.php', { method: 'POST', ... })
```

Chart.js colors are read from CSS vars at chart-create time via
`getComputedStyle(document.documentElement).getPropertyValue('--violet-500')`
— so charts need a **re-render** when the theme flips. The prototype
does this by passing a `themeKey` prop down to chart components — for
vanilla JS, destroy + recreate the Chart instances after a theme change.

---

## Charts (Chart.js)

Two chart components, both already exist in
`prototype/components.jsx → CategoryChart` and `MonthlyChart`. Port
to plain JS:

- **CategoryChart**: donut (default) or bar.
  - Donut cutout `'68%'`, `borderWidth: 3` matching `--bg-elev` to fake
    "ring" segments, `hoverOffset: 6`.
  - Bar: `borderRadius: 8`, no `borderWidth`.
  - Tooltip styled: bg `--text`, body `--bg-elev`, padding 10, radius 8,
    no color swatch.
  - Legend hidden — show a custom legend below the chart with category
    color swatches.

- **MonthlyChart**: bar (default) or area line. 6 months back, all in
  violet (`--violet-500`), `borderRadius: 8`.

Both **must beginAtZero**.

---

## Security checklist (per original brief)

- All SQL via **PDO prepared statements**. No string interpolation.
- Passwords via `password_hash($pw, PASSWORD_DEFAULT)` + `password_verify()`.
- Sessions: `session_start()` at top of every protected page;
  `session_regenerate_id(true)` on login.
- Session cookie flags: `httponly`, `samesite=Lax`, `secure` when HTTPS.
- CSRF token on every POST form (`<input type="hidden" name="_csrf">`).
- Validate + cast all inputs (`filter_var`, `(float)`, etc.).
- Escape on output: `htmlspecialchars($s, ENT_QUOTES, 'UTF-8')`.
- `expenses.user_id` foreign key + every query scoped to
  `WHERE user_id = :uid`. Never trust an `expense_id` from the client
  without re-checking ownership.

---

## Files in this bundle

```
design_handoff_mira/
├── README.md                                 ← you are here
├── schema.sql                                ← MySQL DDL — users + expenses
├── backend_reference/
│   └── Categorizer.php                       ← drop-in PHP port of the AI categorizer
└── prototype/                                ← design reference (HTML/React)
    ├── Personal AI Accountant.html           ← entry point — open in any browser
    ├── styles.css                            ← all design tokens + components
    ├── data.js                               ← AI logic, insights, i18n, seed data
    ├── components.jsx                        ← Sidebar, TopBar, icons, charts
    ├── views.jsx                             ← all 7 screens + Add Expense modal
    ├── app.jsx                               ← top-level routing + state
    └── tweaks-panel.jsx                      ← (ignore — design-time tweak UI)
```

To preview the prototype: open `prototype/Personal AI Accountant.html`
directly in a browser. It runs entirely client-side (no build step,
React via CDN, data in localStorage).

---

## Open questions / decisions for the implementer

1. **OpenAI / real LLM?** Brief says no external APIs for v1 — keyword
   categorization only. Architect `Categorizer.php` so swapping in an
   LLM call later is a single-method change. (Premium tier could upgrade to real LLM.)
2. **Multi-currency exchange rates?** For the multi-currency premium feature, you'll
   need a rates API (e.g., `exchangerate.host` free tier or Open Exchange Rates). Cache
   rates in a `exchange_rates` table, refreshed daily via a cron job.
3. **Email delivery for digests?** Use PHPMailer + SMTP (e.g., Resend or Mailgun free
   tier). Keep the mailer behind a simple `Mailer.php` wrapper so the transport is
   swappable.
4. **Mobile drawer nav?** The prototype hides the sidebar below 980px without a
   replacement. For production, add a hamburger button in the top bar that opens a
   side drawer.
5. **CSV import column mapping?** Different banks export different column orders. Show
   a column-mapping step after upload (e.g., "which column is the amount?") before
   confirming the import.

---

## Plans & Monetization

Mira ships with two tiers. All existing screens belong to the **Free** tier. Premium
features are behind a single PHP guard: `Plan::require($user)` which redirects to
`/premium.php` with a `?from=` hint so users know which feature triggered the upsell.

### Tiers

| Feature | Free | Premium |
|---|---|---|
| Expense tracking | ✓ | ✓ |
| AI categorization | ✓ | ✓ |
| AI insights (rule-based) | ✓ | ✓ |
| Dashboard + charts | ✓ | ✓ |
| EN/ES + dark mode | ✓ | ✓ |
| Expense history | Last 3 months | Unlimited |
| Monthly expenses cap | 50/month | Unlimited |
| **Budget Goals** | — | ✓ |
| **Recurring Expenses** | — | ✓ |
| **Savings Goals** | — | ✓ |
| **CSV Import** | — | ✓ |
| **Reports & Export** | — | ✓ |
| **Weekly Email Digest** | — | ✓ |
| **Multi-currency** | — | ✓ |

### Pricing

| Plan | Price | Stripe price ID env var |
|---|---|---|
| Monthly | $4.99 / month | `STRIPE_PRICE_MONTHLY` |
| Annual | $39.99 / year (~$3.33/mo) | `STRIPE_PRICE_ANNUAL` |
| 14-day trial | Free | auto-applied on register |

---

## Premium Features

### 1. Budget Goals

**Screen:** `budgets.php`
**API:** `api/budgets_save.php` (POST), `api/budgets_list.php` (GET), `api/budgets_delete.php` (POST)
**Backend:** `includes/BudgetEngine.php`

Users set a monthly (or weekly) spending limit per category. The dashboard gains a
compact **Budget bar** section beneath the stat row showing each active budget as a
progress bar with the current spend vs. the limit.

```
[🍔 Food & Drink]  $312 / $400  ━━━━━━━━░░░░  78%   ← orange above 80%
[📺 Subscriptions] $87  / $80   ━━━━━━━━━━━━ 109%   ← red, over budget
```

**Budget card anatomy (budgets.php):**
- Header: category tile + name + "Set Budget" CTA if none exists.
- Each row: progress bar (color tracks %, green→amber→red), current/limit amounts,
  percent label, "Edit" / "Remove" icon buttons.
- Edit modal: amount input + period toggle (monthly/weekly) + notify-at selector
  (50% / 80% / 100% / Off).

**BudgetEngine.php methods:**
```php
BudgetEngine::forUser(int $userId, string $period = 'monthly'): array
// Returns all budgets with ->spent, ->limit, ->pct, ->status ('ok'|'warn'|'over')

BudgetEngine::upsert(int $userId, string $category, float $amount, string $period, int $notifyAt): void
BudgetEngine::delete(int $userId, string $category, string $period): void
```

**Dashboard integration:** After the stat row, render a `budget-overview` card only
when the user has ≥1 active budget. Show up to 4 bars; "See all" links to `budgets.php`.

---

### 2. Recurring Expenses

**Screen:** `recurring.php`
**API:** `api/recurring_*.php` (create / update / delete / log-now)
**Backend:** `includes/RecurringEngine.php`

A dedicated screen listing all recurring bills (rent, Netflix, gym…). Each entry shows
the title, amount, frequency, and next due date. A badge highlights bills due within
7 days.

**Screen layout:**
- **"Due soon" banner** (amber, top) — lists any recurring item with `next_due ≤ today + 7`.
- **All recurring expenses** table: icon tile | title + notes | frequency chip | next due | amount | active toggle | actions.
- **Add/Edit modal** fields: Title, Amount, Category, Frequency (weekly/biweekly/monthly/yearly),
  Next due date, Auto-add toggle (adds the expense automatically on the due date), Notes.

**RecurringEngine.php methods:**
```php
RecurringEngine::dueWithin(int $userId, int $days = 7): array
RecurringEngine::advanceDueDate(int $recurringId): void  // call after logging
RecurringEngine::logNow(int $recurringId, int $userId): int  // inserts expense row, advances due date, returns new expense id
```

**Cron hook** (`cron/auto_log_recurring.php` — run daily via XAMPP Task Scheduler or
a real cron): For every active recurring with `auto_add = 1` and `next_due <= CURDATE()`,
call `RecurringEngine::logNow()` and advance the due date.

**Dashboard integration:** A "Coming up" mini-card on the dashboard sidebar (or beneath
the recent expenses card) shows the next 3 due items.

---

### 3. Savings Goals

**Screen:** `goals.php`
**API:** `api/goals_*.php` (create / contribute / complete / delete)
**Backend:** `includes/GoalsEngine.php`

A visual goal tracker. Users create goals (e.g., "Emergency fund — $3,000") and log
contributions over time. A circular progress ring fills as the goal approaches 100%.

**Goal card anatomy:**
- 64px circular progress ring (SVG stroke-dashoffset animation) in violet.
- Emoji + title (large) + target amount.
- `saved / target` and a pill showing `X% reached`.
- `On track` / `Needs attention` badge based on target date proximity.
- "+ Add funds" button → inline amount input → POST to `api/goals_contribute.php`.
- Contribution history accordion — date + amount + note per row.

**GoalsEngine.php methods:**
```php
GoalsEngine::forUser(int $userId): array
// Each item has ->pct, ->on_track (bool), ->days_remaining, ->monthly_needed
GoalsEngine::contribute(int $goalId, int $userId, float $amount, string $note, string $date): void
GoalsEngine::markComplete(int $goalId, int $userId): void
```

**Dashboard integration:** A compact "Goals" card shows up to 3 active goals as slim
progress bars, linked to `goals.php`.

---

### 4. CSV Import

**Screen:** `import.php`
**API:** `api/import_upload.php` (POST multipart), `api/import_confirm.php` (POST JSON)
**Backend:** `includes/CsvImporter.php`

Lets users paste or upload a CSV from their bank. Two-step flow:

**Step 1 — Upload & Map** (`import.php`):
- Drag-and-drop zone + "Browse" fallback. Accepts `.csv` and `.txt`, max 2 MB.
- After upload, server reads the first 5 rows and returns them as a preview table.
- User maps columns: Date → col X, Description → col Y, Amount → col Z (debit/credit
  split or signed single column). Locale for the date format (MM/DD/YYYY vs DD/MM/YYYY).

**Step 2 — Review & Confirm** (`import.php` — same page, JS step):
- Shows all detected rows with AI-suggested categories pre-filled.
- Inline category override per row (same chip UI as the Add Expense modal).
- "Skip" checkbox on rows the user wants to exclude.
- "Import N expenses" confirm button → POST to `api/import_confirm.php`.

**CsvImporter.php methods:**
```php
CsvImporter::parse(string $filePath, array $mapping): array  // returns raw rows
CsvImporter::preview(array $rows, int $limit = 5): array
CsvImporter::import(int $userId, array $rows): array  // ['imported'=>N, 'skipped'=>N]
```

Rules: skip rows where amount is 0 or null; skip duplicate detection (same title +
amount + date already exists for that user); create a `csv_imports` audit row.

---

### 5. Reports & Export

**Screen:** `reports.php`
**API:** `api/export.php` (GET with query params)
**Backend:** `includes/ReportBuilder.php`

Users generate and download expense reports as **CSV** or **PDF**.

**Report builder UI (`reports.php`):**
- Date range picker: preset buttons (This month / Last month / Last 3 months / Custom)
  + custom from/to date inputs.
- Category multi-select filter.
- Format toggle: CSV / PDF.
- "Generate report" button → triggers download via `api/export.php?format=csv&from=…`.

**CSV export:** Columns — Date, Title, Category, Amount, Currency, Description,
AI Categorized. UTF-8 with BOM so Excel opens it correctly.

**PDF export:** Use [FPDF](http://www.fpdf.org/) (no-dependency PHP PDF library):
- Cover section: "Mira Expense Report — {name} — {period}".
- Summary table: total spent, top category, transaction count, avg per day.
- Category breakdown with amounts + percentages.
- Full expense list, grouped by category, sorted by date.

**ReportBuilder.php:**
```php
ReportBuilder::csv(int $userId, array $filters): string   // returns CSV string
ReportBuilder::pdf(int $userId, array $filters): string   // returns PDF binary
```

---

### 6. Weekly Email Digest  *(Premium)*

**Backend:** `includes/DigestMailer.php`, `cron/send_weekly_digests.php`
**Email template:** `includes/email_templates/weekly_digest.php` (plain HTML)

Every Monday morning, premium users receive a one-page email summary of their previous
week:

- **Subject:** "Your Mira Week: $X spent, top category was {cat}"
- **Body sections:**
  1. Week total vs. prior week delta.
  2. Category breakdown — top 4 as a simple bar list (HTML table).
  3. One highlighted insight ("You cut Entertainment by $42!").
  4. Upcoming recurring bills due this week (from `recurring_expenses`).
  5. CTA: "View full dashboard →".

**DigestMailer.php:**
```php
DigestMailer::sendForUser(array $user): bool
DigestMailer::buildSubject(array $stats, string $lang): string
DigestMailer::buildBody(array $user, array $stats, array $insights, array $upcoming): string
```

Email uses PHPMailer. SMTP credentials live in `config/mail.php` (not committed).
The `weekly_digests` table prevents duplicate sends (unique on `user_id + week_start`).

**Opt-out:** Settings page gains a "Weekly email digest" toggle (stored on the `users`
row — add a `digest_enabled` TINYINT column).

---

### 7. Multi-currency  *(Premium)*

**Backend:** `includes/CurrencyConverter.php`, `cron/refresh_exchange_rates.php`
**New table:** `exchange_rates (base VARCHAR(8), target VARCHAR(8), rate DECIMAL(14,6), updated_at DATETIME)`

When multi-currency is enabled, the Add Expense modal gains a currency selector
dropdown next to the amount field. Users can record an expense in EUR, MXN, GBP, etc.

**Conversion logic:**
- On save, `CurrencyConverter::toUSD($amount, $currency)` populates `expenses.amount_usd`
  using today's rate from the `exchange_rates` table.
- All dashboard totals and chart aggregations use `amount_usd` instead of `amount` when
  the user has multi-currency expenses.
- The dashboard stat row shows a ≈ tilde prefix ("≈ $1,234") and a tooltip explaining
  "Converted from original currencies at daily rates."

**Currency selector:** Show ISO code + flag emoji. Pre-populate with the user's
`users.currency` setting. Support at minimum: USD, EUR, GBP, MXN, CAD, ARS, COP, CLP.

---

## Payment & Subscription System

### Stripe integration

**Dependencies:** Stripe PHP SDK (`composer require stripe/stripe-php`). If Composer is
unavailable, use Stripe's single-file bundle from their GitHub releases.

**Config** (`config/stripe.php` — not committed):
```php
define('STRIPE_SECRET_KEY',     getenv('STRIPE_SECRET_KEY'));
define('STRIPE_PUBLISHABLE_KEY', getenv('STRIPE_PUBLISHABLE_KEY'));
define('STRIPE_WEBHOOK_SECRET', getenv('STRIPE_WEBHOOK_SECRET'));
define('STRIPE_PRICE_MONTHLY',  getenv('STRIPE_PRICE_MONTHLY'));  // price_xxx
define('STRIPE_PRICE_ANNUAL',   getenv('STRIPE_PRICE_ANNUAL'));
```

**New files:**
```
public/
├── premium.php          ← pricing / upgrade page (upsell landing)
├── billing.php          ← manage subscription (cancel, switch plan, invoices)
api/
├── stripe_checkout.php  ← POST {plan:'monthly'|'annual'} → redirect to Stripe Checkout
├── stripe_portal.php    ← POST → redirect to Stripe Customer Portal
├── stripe_webhook.php   ← POST (raw body) → handles Stripe events
includes/
├── Plan.php             ← plan gating helper
├── StripeHelper.php     ← thin wrapper around Stripe SDK calls
```

### Plan.php — feature gating

```php
class Plan {
    // Returns true if user is on premium (or active trial)
    public static function isPremium(array $user): bool;

    // Redirects to /premium.php?from={hint} if user is not premium.
    // Call at the top of every premium screen/endpoint.
    public static function require(array $user, string $hint = ''): void;

    // Returns remaining trial days (0 if expired or not in trial)
    public static function trialDaysLeft(array $user): int;

    // Hard cap for free users
    public static function monthlyExpenseCount(array $user): int;  // 50
    public static function historyMonths(array $user): int;         // 3 (free) / unlimited (premium)
}
```

### premium.php — upgrade / pricing page

- Full-width hero: "Unlock the full Mira" + gradient background.
- Side-by-side plan cards: **Monthly** ($4.99/mo) | **Annual** ($39.99/yr — "Save 33%"
  badge).
- Feature comparison table below.
- Trial reminder bar if `Plan::trialDaysLeft($user) > 0`:
  "You have X days left in your free trial. Upgrade to keep your data."
- CTA buttons POST to `/api/stripe_checkout.php` with the chosen plan.
- "Already subscribed?" link → `/billing.php`.

### stripe_checkout.php

1. Create or retrieve the Stripe customer for the user.
2. Call `\Stripe\Checkout\Session::create()` with the chosen price ID, `success_url`,
   `cancel_url`, and `client_reference_id = $user['id']`.
3. Redirect to `$session->url`.

### stripe_webhook.php

Handle these events (verify signature first with `\Stripe\Webhook::constructEvent()`):

| Event | Action |
|---|---|
| `checkout.session.completed` | Create `subscriptions` row; set `users.plan = 'premium'`; store `stripe_customer_id` |
| `invoice.payment_succeeded` | Update `subscriptions.current_period_end` |
| `invoice.payment_failed` | Set `subscriptions.status = 'past_due'`; email user |
| `customer.subscription.updated` | Sync `plan`, `status`, `cancel_at_period_end` |
| `customer.subscription.deleted` | Set `users.plan = 'free'`; set `subscriptions.status = 'canceled'` |

### billing.php — subscription management

- Shows current plan + renewal date + status badge.
- "Manage billing" button → POST `/api/stripe_portal.php` → redirect to Stripe Customer
  Portal (handles cancellation, card update, invoice history — zero custom UI needed).
- If `cancel_at_period_end = 1`, shows amber banner "Your plan cancels on {date}. Renew?"
  with a "Keep Premium" button.

### Free tier enforcement

Apply limits in two places:

1. **`api/expenses_create.php`** — before inserting, check:
   ```php
   if (!Plan::isPremium($user)) {
       $count = Db::scalar('SELECT COUNT(*) FROM expenses
                            WHERE user_id=? AND MONTH(expense_date)=MONTH(NOW())
                            AND YEAR(expense_date)=YEAR(NOW())', [$uid]);
       if ($count >= 50) die(json_encode(['error'=>'limit_reached']));
   }
   ```

2. **`api/expenses_list.php`** — for free users, add `AND expense_date >= DATE_SUB(NOW(), INTERVAL 3 MONTH)` to the query.

3. **Premium screens** (`budgets.php`, `recurring.php`, etc.) — top of each file:
   ```php
   Plan::require($user, 'budgets');
   ```

### Free-tier limit UI

When a free user's expense count approaches 50, the dashboard shows a soft warning card:
"You've added 47/50 expenses this month. Upgrade to Premium for unlimited tracking."
At 50, the "+ Add expense" button is replaced by a locked state that opens `/premium.php`.

---

## Updated file structure

```
mira/
├── public/
│   ├── index.php
│   ├── login.php / register.php / logout.php
│   ├── dashboard.php
│   ├── expenses.php
│   ├── insights.php
│   ├── categories.php / category.php
│   ├── settings.php
│   ├── premium.php          ← NEW — pricing / upgrade page
│   ├── billing.php          ← NEW — subscription management
│   ├── budgets.php          ← NEW [PREMIUM]
│   ├── recurring.php        ← NEW [PREMIUM]
│   ├── goals.php            ← NEW [PREMIUM]
│   ├── import.php           ← NEW [PREMIUM]
│   ├── reports.php          ← NEW [PREMIUM]
│   └── assets/ …
│   └── api/
│       ├── expenses_*.php
│       ├── categorize.php
│       ├── insights.php
│       ├── stripe_checkout.php   ← NEW
│       ├── stripe_portal.php     ← NEW
│       ├── stripe_webhook.php    ← NEW
│       ├── budgets_*.php         ← NEW [PREMIUM]
│       ├── recurring_*.php       ← NEW [PREMIUM]
│       ├── goals_*.php           ← NEW [PREMIUM]
│       ├── import_upload.php     ← NEW [PREMIUM]
│       ├── import_confirm.php    ← NEW [PREMIUM]
│       └── export.php            ← NEW [PREMIUM]
├── includes/
│   ├── db.php / auth.php / helpers.php / i18n.php
│   ├── Categorizer.php / InsightsEngine.php
│   ├── Plan.php              ← NEW — plan gating
│   ├── StripeHelper.php      ← NEW — Stripe SDK wrapper
│   ├── BudgetEngine.php      ← NEW [PREMIUM]
│   ├── RecurringEngine.php   ← NEW [PREMIUM]
│   ├── GoalsEngine.php       ← NEW [PREMIUM]
│   ├── CsvImporter.php       ← NEW [PREMIUM]
│   ├── ReportBuilder.php     ← NEW [PREMIUM]
│   ├── DigestMailer.php      ← NEW [PREMIUM]
│   ├── CurrencyConverter.php ← NEW [PREMIUM]
│   └── email_templates/
│       └── weekly_digest.php ← NEW [PREMIUM]
├── cron/
│   ├── auto_log_recurring.php   ← NEW — daily
│   ├── send_weekly_digests.php  ← NEW — every Monday
│   └── refresh_exchange_rates.php ← NEW — daily
├── config/
│   ├── db.php           ← NOT committed
│   ├── stripe.php       ← NOT committed
│   └── mail.php         ← NOT committed
└── schema.sql
```

---

## Sidebar navigation (updated)

Add Premium-gated items to the sidebar. Show a lock icon (🔒) on items the free user
cannot access — clicking them goes to `/premium.php?from={slug}`.

```
Dashboard
Expenses
Insights
Categories
─────────────
✨ Budgets          ← Premium
✨ Recurring        ← Premium
✨ Goals            ← Premium
✨ Import           ← Premium
✨ Reports          ← Premium
─────────────
Settings
[Upgrade to Premium]  ← shown only to free users, violet CTA chip
```

---

## Open questions / decisions for the implementer

1. **Real LLM for insights?** The keyword categorizer is the foundation. A natural
   Premium upsell would be replacing `InsightsEngine` with an LLM call (Claude API)
   that generates truly personalized, narrative insights. Architect with a
   `InsightsEngine::generate()` interface so the implementation is swappable.
2. **Exchange rate API?** `exchangerate.host` has a generous free tier (no key needed
   for basic use). Cache rates daily in a `exchange_rates` table; fall back to last
   known rate if the API is unreachable.
3. **Email deliverability?** For production, use a transactional email service
   (Resend, Mailgun, Postmark). PHPMailer's SMTP adapter works with all of them.
4. **CSV column mapping UX?** Different banks export radically different headers.
   Consider a "preset" dropdown (Chase, Bank of America, HSBC…) that auto-fills the
   mapping, with a manual fallback.
5. **Mobile drawer nav?** The prototype hides the sidebar below 980px without a
   replacement. For production, add a hamburger button in the top bar that opens a
   side drawer. Premium items in the drawer should still show the lock/upgrade CTA.
