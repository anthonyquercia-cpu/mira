<?php
/**
 * Mira — AI Categorizer (PHP reference)
 *
 * This is a direct port of the JS `categorize()` function in the prototype's
 * `data.js`. Same keyword lists, same scoring, same return shape — so the
 * server-side categorization matches what the design shows in the "Add
 * expense" modal preview.
 *
 * Usage:
 *   require_once __DIR__ . '/Categorizer.php';
 *   $result = Categorizer::categorize($title, $description);
 *   // → ['category' => 'transport', 'confidence' => 0.92, 'alternatives' => ['food']]
 *
 * To extend: add keywords to the KEYWORDS array. Longer keywords score
 * higher per-match (ceil(strlen / 3)) so brand names beat generic words.
 */

final class Categorizer
{
    /** @var array<string, string[]> Slug → list of lowercase keywords */
    private const KEYWORDS = [
        'food' => [
            'mcdonald', 'mcdo', 'starbucks', 'burger', 'pizza', 'sushi',
            'tacos', 'taco bell', 'kfc', 'subway', 'chipotle', 'wendy',
            'domino', 'papa john', 'dunkin', 'tim hortons', 'cafe', 'café',
            'coffee', 'restaurant', 'restaurante', 'comida', 'almuerzo',
            'cena', 'desayuno', 'breakfast', 'lunch', 'dinner', 'groceries',
            'supermercado', 'walmart food', 'kroger', 'safeway',
            'whole foods', 'trader joe', 'costco food', 'panaderia',
            'bakery', 'doordash', 'rappi', 'ubereats', 'uber eats',
            'didi food', 'deli', 'snack', 'agua', 'soda', 'beer', 'cerveza',
            'vino', 'wine', 'bar', 'pub', 'ipa',
        ],
        'transport' => [
            'uber', 'lyft', 'didi', 'cabify', 'taxi', 'bolt', 'gasolina',
            'gas', 'fuel', 'shell', 'exxon', 'mobil', 'chevron', 'bp ',
            'metro', 'subway transit', 'bus', 'autobus', 'tren', 'train',
            'amtrak', 'parking', 'estacionamiento', 'toll', 'peaje',
            'aeropuerto', 'airport', 'vuelo', 'flight', 'airline', 'delta',
            'united', 'american airlines', 'aeromexico', 'avianca',
            'spirit', 'southwest', 'car wash', 'lavado', 'mecanico',
            'mechanic', 'oil change', 'tire', 'llanta',
        ],
        'entertain' => [
            'cinepolis', 'cinemex', 'amc', 'regal', 'imax', 'cinema',
            'movie', 'pelicula', 'concierto', 'concert', 'ticketmaster',
            'stubhub', 'boleto', 'ticket', 'theater', 'teatro', 'museo',
            'museum', 'bowling', 'game', 'spotify event', 'festival',
            'club', 'casino', 'arcade', 'minigolf', 'park ticket',
            'disney park',
        ],
        'health' => [
            'pharmacy', 'farmacia', 'cvs', 'walgreens', 'rite aid',
            'doctor', 'doctor visit', 'clinic', 'clinica', 'hospital',
            'dentist', 'dentista', 'therapy', 'therapist', 'terapia',
            'gym', 'gimnasio', 'fitness', 'yoga', 'pilates', 'vitamin',
            'vitamina', 'medicine', 'medicina', 'medication', 'lab',
            'laboratorio', 'consulta',
        ],
        'subs' => [
            'netflix', 'spotify', 'apple music', 'amazon prime', 'hbo',
            'disney+', 'disney plus', 'hulu', 'youtube premium',
            'youtube music', 'icloud', 'google one', 'dropbox', 'notion',
            'github', 'openai', 'chatgpt', 'claude', 'anthropic',
            'midjourney', 'linkedin premium', 'audible', 'kindle',
            'patreon', 'substack', 'twitch', 'paramount', 'peacock',
            'discovery', 'starz', 'showtime', 'crunchyroll', 'duolingo',
            'headspace', 'calm', '1password', 'evernote', 'figma', 'adobe',
            'canva', 'monthly subscription', 'annual subscription',
            'renewal',
        ],
        'shopping' => [
            'amazon', 'ebay', 'etsy', 'mercadolibre', 'aliexpress', 'shein',
            'zara', 'h&m', 'h and m', 'uniqlo', 'nike', 'adidas',
            'apple store', 'best buy', 'target', 'walmart', 'macy',
            'nordstrom', 'sephora', 'ulta', 'lego', 'ikea purchase',
            'shop', 'boutique', 'store', 'tienda', 'online order',
            'pedido', 'shopify',
        ],
        'home' => [
            'rent', 'renta', 'alquiler', 'mortgage', 'hipoteca', 'electric',
            'electricidad', 'luz', 'water', 'agua bill', 'gas bill',
            'internet', 'wifi', 'comcast', 'spectrum', 'verizon', 'at&t',
            'att', 't-mobile', 'cellphone', 'phone bill', 'telefono',
            'ikea', 'home depot', 'lowes', 'furniture', 'muebles',
            'cleaning', 'limpieza', 'hoa', 'condo', 'apartment',
            'household', 'casa',
        ],
    ];

    /**
     * @return array{category:string, confidence:float, alternatives:string[]}
     */
    public static function categorize(string $title, string $description = ''): array
    {
        $text = mb_strtolower(trim($title . ' ' . $description));
        if ($text === '') {
            return ['category' => 'other', 'confidence' => 0.0, 'alternatives' => []];
        }

        $scores = [];
        foreach (self::KEYWORDS as $cat => $keywords) {
            $scores[$cat] = 0;
            foreach ($keywords as $kw) {
                if (str_contains($text, $kw)) {
                    // Longer keywords are more specific → higher per-match weight
                    $scores[$cat] += max(1, (int) floor(strlen($kw) / 3));
                }
            }
        }

        arsort($scores);
        $ranked = $scores;
        $topCat = array_key_first($ranked);
        $topScore = $ranked[$topCat];

        if ($topScore === 0) {
            return ['category' => 'other', 'confidence' => 0.0, 'alternatives' => []];
        }

        $total = array_sum($ranked);
        $confidence = min(0.99, 0.5 + ($topScore / max($total, $topScore)) * 0.5);

        $alternatives = [];
        $i = 0;
        foreach ($ranked as $cat => $score) {
            if ($cat === $topCat) continue;
            if ($score <= 0) continue;
            $alternatives[] = $cat;
            if (++$i >= 3) break;
        }

        return [
            'category'     => $topCat,
            'confidence'   => round($confidence, 2),
            'alternatives' => $alternatives,
        ];
    }
}
