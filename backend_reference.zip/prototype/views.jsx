/* All app views: Dashboard, Expenses, Insights, Categories, CategoryDetail, Settings, Login */
/* eslint-disable */
// Names already in global scope from components.jsx: React hooks, CATEGORIES,
// CAT_BY_ID, CAT_ICONS, formatMoney, formatDate, sum, groupByCategory.
// Only pull what's new here.
const {
  categorize, generateInsights, dashboardSummary,
  sameMonth, formatDateLong,
} = window.PAA;

/* ============================================================ */
/* DASHBOARD                                                    */
/* ============================================================ */
function DashboardView({ expenses, t, lang, chartType, setRoute, openCategory }) {
  const now = new Date();
  const thisMonth = expenses.filter(e => sameMonth(new Date(e.date), now));
  const lastMonth = expenses.filter(e => {
    const d = new Date(e.date);
    const lm = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    return sameMonth(d, lm);
  });

  const totalThis = sum(thisMonth);
  const totalLast = sum(lastMonth);
  const deltaPct = totalLast ? Math.round(((totalThis - totalLast) / totalLast) * 100) : 0;

  const byCat = groupByCategory(thisMonth);
  const ranked = Object.entries(byCat).sort((a, b) => b[1] - a[1]);
  const topCat = ranked[0];

  const day = now.getDate();
  const avgPerDay = day ? totalThis / day : 0;

  const summary = dashboardSummary(expenses, lang);
  const recentExpenses = [...expenses].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 6);

  return (
    <div className="content fade-in">
      {/* AI summary hero */}
      <div className="ai-summary" style={{ marginBottom: 20 }}>
        <div className="ai-summary__avatar">
          <Icon name="sparkle" size={20} />
        </div>
        <div style={{ flex: 1 }}>
          <div className="ai-summary__name">{"Mira"}</div>
          <div className="ai-summary__text">{summary}</div>
        </div>
      </div>

      {/* Stat row */}
      <div className="stat-grid">
        <div className="stat stat--feature">
          <div className="stat__label">{t.statMonthTotal}</div>
          <div className="stat__value">{formatMoney(totalThis)}</div>
          {totalLast > 0 && (
            <div className="stat__delta" style={{ background: "rgba(255,255,255,0.18)", color: "white" }}>
              <Icon name={deltaPct > 0 ? "arrowUp" : "arrowDown"} size={12} /> {Math.abs(deltaPct)}% {t.vsLast}
            </div>
          )}
        </div>
        <div className="stat">
          <div className="stat__label">{t.statTransactions}</div>
          <div className="stat__value">{thisMonth.length}</div>
          <div className="stat__delta stat__delta--flat">{lastMonth.length} {t.vsLast}</div>
        </div>
        <div className="stat">
          <div className="stat__label">{t.statAvgDay}</div>
          <div className="stat__value">{formatMoney(avgPerDay)}</div>
          <div className="stat__delta stat__delta--flat">day {day} {lang === "es" ? "del mes" : "of month"}</div>
        </div>
        <div className="stat">
          <div className="stat__label">{t.statTopCat}</div>
          {topCat ? (
            <>
              <div className="stat__value" style={{ fontSize: 22 }}>{t.cats[topCat[0]]}</div>
              <div className="stat__delta stat__delta--flat">
                <span className="chip__dot" style={{ background: `var(--c-${topCat[0]})` }}></span>
                {formatMoney(topCat[1])}
              </div>
            </>
          ) : (
            <>
              <div className="stat__value" style={{ fontSize: 18, color: "var(--text-faint)" }}>—</div>
            </>
          )}
        </div>
      </div>

      {/* Main charts grid */}
      <div className="grid-3" style={{ marginBottom: 20 }}>
        {/* Left: by category — switchable */}
        <div className="card">
          <div className="card__head">
            <div className="card__title-lg">{t.sectionByCat}</div>
            <span className="text-xs muted">{lang === "es" ? "este mes" : "this month"}</span>
          </div>
          {ranked.length === 0 ? (
            <EmptyChart t={t} />
          ) : (
            <>
              <div className={chartType === "donut" ? "chart-wrap chart-wrap--donut" : "chart-wrap"}>
                <CategoryChart expenses={thisMonth} t={t} mode={chartType} themeKey={window.__themeKey} />
                {chartType === "donut" && <DonutCenter total={totalThis} />}
              </div>
              <div style={{ marginTop: 14 }}>
                {ranked.slice(0, 5).map(([cat, amt]) => {
                  const pct = totalThis ? (amt / totalThis) * 100 : 0;
                  return (
                    <div className="bar-row" key={cat} onClick={() => openCategory(cat)} style={{ cursor: "pointer" }}>
                      <span className="bar-row__swatch" style={{ background: `var(--c-${cat})` }}></span>
                      <div>
                        <div className="bar-row__label">{t.cats[cat]}</div>
                        <div className="bar-row__bar"><div style={{ width: pct + "%", background: `var(--c-${cat})` }}></div></div>
                      </div>
                      <div className="bar-row__amount">{formatMoney(amt)}</div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>

        {/* Right: top category preview */}
        <div className="card">
          <div className="card__head">
            <div className="card__title-lg">{lang === "es" ? "Top categoría" : "Top category"}</div>
          </div>
          {topCat ? (
            <TopCategoryPreview cat={topCat[0]} amount={topCat[1]} total={totalThis} expenses={thisMonth} t={t} openCategory={openCategory} />
          ) : <EmptyChart t={t} />}
        </div>
      </div>

      {/* Monthly trend */}
      <div className="card" style={{ marginBottom: 20 }}>
        <div className="card__head">
          <div>
            <div className="card__title-lg">{t.sectionMonthly}</div>
            <div className="text-xs muted" style={{ marginTop: 2 }}>{lang === "es" ? "Últimos 6 meses" : "Last 6 months"}</div>
          </div>
        </div>
        <div className="chart-wrap chart-wrap--lg">
          <MonthlyChart expenses={expenses} lang={lang} themeKey={window.__themeKey} mode="bars" />
        </div>
      </div>

      {/* Recent expenses */}
      <div className="card">
        <div className="card__head">
          <div className="card__title-lg">{t.sectionRecent}</div>
          <button className="btn btn--ghost" onClick={() => setRoute("expenses")} style={{ padding: "6px 10px" }}>
            {t.seeAll} <Icon name="chevronRight" size={14} />
          </button>
        </div>
        <div className="expense-list">
          {recentExpenses.map(e => <ExpenseRow key={e.id} e={e} t={t} lang={lang} />)}
        </div>
      </div>
    </div>
  );
}

function EmptyChart({ t }) {
  return (
    <div className="empty">
      <div className="empty__icon"><Icon name="inbox" size={24} /></div>
      <div style={{ fontSize: 13 }}>{t.aiSumEmpty}</div>
    </div>
  );
}

function TopCategoryPreview({ cat, amount, total, expenses, t, openCategory }) {
  const pct = total ? Math.round((amount / total) * 100) : 0;
  const inCat = expenses.filter(e => e.category === cat).slice(0, 3);
  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 18 }}>
        <CategoryDot cat={cat} size={56} />
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 16, fontWeight: 600 }}>{t.cats[cat]}</div>
          <div className="text-xs muted">{pct}% {t.vsLast.split(" ")[0]} total</div>
        </div>
      </div>
      <div style={{ fontSize: 28, fontWeight: 600, letterSpacing: "-0.02em", marginBottom: 14 }}>
        {formatMoney(amount)}
      </div>
      <div style={{ borderTop: "1px solid var(--border)", paddingTop: 10 }}>
        {inCat.map(e => (
          <div key={e.id} style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", fontSize: 13 }}>
            <span>{e.title}</span>
            <span className="mono">{formatMoney(e.amount)}</span>
          </div>
        ))}
      </div>
      <button className="btn btn--ghost" onClick={() => openCategory(cat)} style={{ padding: "6px 0", marginTop: 8, color: "var(--violet-500)" }}>
        {t.seeAll} <Icon name="chevronRight" size={14} />
      </button>
    </div>
  );
}

function ExpenseRow({ e, t, lang, onClick }) {
  return (
    <div className="expense-row" onClick={onClick}>
      <CategoryDot cat={e.category} />
      <div>
        <div className="expense-row__title">{e.title}</div>
        <div className="expense-row__meta">
          <span className="chip">
            <span className="chip__dot" style={{ background: `var(--c-${e.category})` }}></span>
            {t.cats[e.category]}
          </span>
          {e.description && <span style={{ marginLeft: 8 }} className="muted">· {e.description}</span>}
        </div>
      </div>
      <div className="expense-row__amount">{formatMoney(e.amount)}</div>
      <div className="expense-row__date">{formatDate(e.date, lang)}</div>
    </div>
  );
}

/* ============================================================ */
/* EXPENSES LIST                                                */
/* ============================================================ */
function ExpensesView({ expenses, t, lang }) {
  const [query, setQuery] = useState("");
  const [period, setPeriod] = useState("thisMonth");
  const [activeCat, setActiveCat] = useState("all");

  const now = new Date();
  const filtered = useMemo(() => {
    return expenses.filter(e => {
      const d = new Date(e.date);
      if (period === "thisMonth" && !sameMonth(d, now)) return false;
      if (period === "lastMonth") {
        const lm = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        if (!sameMonth(d, lm)) return false;
      }
      if (period === "last3") {
        const limit = new Date(now.getFullYear(), now.getMonth() - 3, 1);
        if (d < limit) return false;
      }
      if (activeCat !== "all" && e.category !== activeCat) return false;
      if (query) {
        const q = query.toLowerCase();
        if (!e.title.toLowerCase().includes(q) && !(e.description || "").toLowerCase().includes(q)) return false;
      }
      return true;
    }).sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [expenses, query, period, activeCat]);

  const totalFiltered = sum(filtered);

  return (
    <div className="content fade-in">
      {/* Filters card */}
      <div className="card" style={{ marginBottom: 18 }}>
        <div className="row" style={{ flexWrap: "wrap", gap: 14, marginBottom: 14 }}>
          <div className="search-wrap" style={{ flex: 1, minWidth: 240 }}>
            <span className="input-prefix__icon" style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)" }}>
              <Icon name="search" size={16} />
            </span>
            <input className="input" placeholder={t.search} value={query} onChange={e => setQuery(e.target.value)} />
          </div>
          <div className="seg">
            {[
              ["thisMonth", t.thisMonth],
              ["lastMonth", t.lastMonth],
              ["last3", t.last3],
              ["all", t.allTime],
            ].map(([k, label]) => (
              <button key={k} className={"seg__item " + (period === k ? "is-active" : "")} onClick={() => setPeriod(k)}>{label}</button>
            ))}
          </div>
        </div>
        <div className="filters">
          <button className={"filter-pill " + (activeCat === "all" ? "is-active" : "")} onClick={() => setActiveCat("all")}>
            {t.all} <span style={{ opacity: 0.6 }}>·{expenses.length}</span>
          </button>
          {CATEGORIES.map(c => {
            const count = expenses.filter(e => e.category === c.id).length;
            if (!count) return null;
            return (
              <button key={c.id} className={"filter-pill " + (activeCat === c.id ? "is-active" : "")} onClick={() => setActiveCat(c.id)}>
                <span className="chip__dot" style={{ background: `var(--c-${c.id})` }}></span>
                {t.cats[c.id]} <span style={{ opacity: 0.6 }}>·{count}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Results summary */}
      <div className="row-between" style={{ marginBottom: 12, padding: "0 4px" }}>
        <div className="text-sm muted">
          {filtered.length} {lang === "es" ? "resultados" : "results"}
        </div>
        <div className="text-sm" style={{ fontWeight: 500 }}>
          {lang === "es" ? "Total" : "Total"}: <span className="mono">{formatMoney(totalFiltered)}</span>
        </div>
      </div>

      <div className="card">
        {filtered.length === 0 ? (
          <div className="empty">
            <div className="empty__icon"><Icon name="search" size={22} /></div>
            <div>{t.noResults}</div>
          </div>
        ) : (
          <div className="expense-list">
            {filtered.map(e => <ExpenseRow key={e.id} e={e} t={t} lang={lang} />)}
          </div>
        )}
      </div>
    </div>
  );
}

/* ============================================================ */
/* INSIGHTS                                                     */
/* ============================================================ */
function InsightsView({ expenses, t, lang }) {
  const insights = generateInsights(expenses, lang);
  const iconForTone = {
    coach: "sparkle",
    warn: "trendUp",
    win: "check",
    neutral: "calendar",
  };
  const iconForName = {
    trophy: "trophy", tv: "tv",
    "arrow-up": "trendUp", "trending-up": "trendUp", "trending-down": "trendDown",
    sparkle: "sparkle", calendar: "calendar",
  };

  return (
    <div className="content fade-in" style={{ maxWidth: 760 }}>
      <div className="ai-summary" style={{ marginBottom: 24 }}>
        <div className="ai-summary__avatar">
          <Icon name="sparkle" size={20} />
        </div>
        <div>
          <div className="ai-summary__name">{"Mira"}</div>
          <div className="ai-summary__text">
            {lang === "es"
              ? `Revisé tus últimos ${expenses.length} gastos. Esto es lo que noté:`
              : `I looked at your last ${expenses.length} expenses. Here's what I noticed:`}
          </div>
        </div>
      </div>

      {insights.map((ins, i) => (
        <div key={i}
          className={"insight " + (ins.tone === "coach" ? "insight--coach" : "")}
          style={{
            ...(ins.tone === "win" ? { borderColor: "#9CDDAE" } : {}),
            ...(ins.tone === "warn" ? { borderColor: "#F4B5B5" } : {}),
            animation: `slideUp 280ms ease ${i * 60}ms both`,
          }}>
          <div className="insight__icon"
            style={ins.cat ? { color: `var(--c-${ins.cat})`, background: `color-mix(in oklab, var(--c-${ins.cat}) 18%, transparent)` } : undefined}>
            <Icon name={iconForName[ins.icon] || iconForTone[ins.tone] || "sparkle"} size={18} />
          </div>
          <div className="insight__text">
            <div className="insight__title">{ins.title}</div>
            <div className="insight__body">{ins.body}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ============================================================ */
/* CATEGORIES (grid) + CATEGORY DETAIL                          */
/* ============================================================ */
function CategoriesView({ expenses, t, lang, openCategory }) {
  const now = new Date();
  const thisMonth = expenses.filter(e => sameMonth(new Date(e.date), now));
  const byCat = groupByCategory(thisMonth);
  const total = sum(thisMonth);

  return (
    <div className="content fade-in">
      <div className="grid-2" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))" }}>
        {CATEGORIES.map(c => {
          const amt = byCat[c.id] || 0;
          const pct = total ? Math.round((amt / total) * 100) : 0;
          const count = thisMonth.filter(e => e.category === c.id).length;
          return (
            <div key={c.id} className="card card--clickable" onClick={() => openCategory(c.id)}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
                <CategoryDot cat={c.id} size={44} />
                <span className="chip">
                  {count} {lang === "es" ? "tx" : "tx"}
                </span>
              </div>
              <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 4 }}>{t.cats[c.id]}</div>
              <div style={{ fontSize: 22, fontWeight: 600, letterSpacing: "-0.02em" }}>{formatMoney(amt)}</div>
              <div className="text-xs muted" style={{ marginTop: 4 }}>
                {pct}% {lang === "es" ? "del mes" : "of month"}
              </div>
              <div className="bar-row__bar" style={{ marginTop: 10 }}>
                <div style={{ width: pct + "%", background: `var(--c-${c.id})` }}></div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function CategoryDetailView({ category, expenses, t, lang, setRoute }) {
  const inCat = expenses.filter(e => e.category === category);
  const now = new Date();
  const thisMonth = inCat.filter(e => sameMonth(new Date(e.date), now));
  const monthTotal = sum(thisMonth);

  // Avg per month (last 6 months that have data)
  const monthsSeen = new Set(inCat.map(e => new Date(e.date).toISOString().slice(0, 7)));
  const avg = monthsSeen.size ? sum(inCat) / monthsSeen.size : 0;

  return (
    <div className="content fade-in">
      <button className="btn btn--ghost" onClick={() => setRoute("categories")} style={{ marginBottom: 16, padding: "6px 10px" }}>
        <Icon name="arrowLeft" size={14} /> {t.backTo} {t.nav.categories.toLowerCase()}
      </button>

      <div className="card" style={{ marginBottom: 20 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 18 }}>
          <CategoryDot cat={category} size={64} />
          <div>
            <div style={{ fontSize: 13, color: "var(--text-muted)" }}>{lang === "es" ? "Categoría" : "Category"}</div>
            <div className="h1">{t.cats[category]}</div>
          </div>
        </div>
        <div className="stat-grid" style={{ marginBottom: 0 }}>
          <div className="stat"><div className="stat__label">{t.catTotalThis}</div><div className="stat__value">{formatMoney(monthTotal)}</div></div>
          <div className="stat"><div className="stat__label">{t.catTotalAvg}</div><div className="stat__value">{formatMoney(avg)}</div></div>
          <div className="stat"><div className="stat__label">{t.catCount}</div><div className="stat__value">{thisMonth.length}</div></div>
          <div className="stat">
            <div className="stat__label">{lang === "es" ? "Transacción más alta" : "Highest"}</div>
            <div className="stat__value">{formatMoney(Math.max(0, ...thisMonth.map(e => Number(e.amount))))}</div>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card__head">
          <div className="card__title-lg">{lang === "es" ? "Todos los gastos" : "All expenses"}</div>
        </div>
        {inCat.length === 0 ? (
          <div className="empty"><div>{t.noResults}</div></div>
        ) : (
          <div className="expense-list">
            {[...inCat].sort((a, b) => new Date(b.date) - new Date(a.date)).map(e => (
              <ExpenseRow key={e.id} e={e} t={t} lang={lang} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ============================================================ */
/* SETTINGS                                                     */
/* ============================================================ */
function SettingsView({ t, lang, setLang, theme, setTheme, user, onReset }) {
  return (
    <div className="content fade-in" style={{ maxWidth: 700 }}>
      <div className="card" style={{ marginBottom: 18 }}>
        <div className="card__head"><div className="card__title-lg">{t.profile}</div></div>
        <div className="row" style={{ marginBottom: 18 }}>
          <span className="avatar avatar--lg">{(user.name || "S")[0].toUpperCase()}</span>
          <div>
            <div style={{ fontSize: 17, fontWeight: 600 }}>{user.name}</div>
            <div className="muted text-sm">{user.email}</div>
          </div>
        </div>
        <div className="field">
          <label className="field__label">{t.name}</label>
          <input className="input" defaultValue={user.name} />
        </div>
        <div className="field">
          <label className="field__label">{t.email}</label>
          <input className="input" defaultValue={user.email} />
        </div>
      </div>

      <div className="card" style={{ marginBottom: 18 }}>
        <div className="card__head"><div className="card__title-lg">{t.appearance}</div></div>
        <div className="row-between" style={{ padding: "8px 0", borderBottom: "1px solid var(--border)" }}>
          <div>
            <div style={{ fontSize: 14, fontWeight: 500 }}>{t.darkMode}</div>
            <div className="text-xs muted">{lang === "es" ? "Cambia el tema general de la app." : "Switch the app's overall theme."}</div>
          </div>
          <button className={"switch " + (theme === "dark" ? "is-on" : "")} onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
            <span className="switch__track"><span className="switch__thumb"></span></span>
          </button>
        </div>
        <div className="row-between" style={{ padding: "12px 0 8px" }}>
          <div>
            <div style={{ fontSize: 14, fontWeight: 500 }}>{t.language}</div>
            <div className="text-xs muted">{lang === "es" ? "Idioma de la interfaz." : "Interface language."}</div>
          </div>
          <div className="seg">
            <button className={"seg__item " + (lang === "en" ? "is-active" : "")} onClick={() => setLang("en")}>English</button>
            <button className={"seg__item " + (lang === "es" ? "is-active" : "")} onClick={() => setLang("es")}>Español</button>
          </div>
        </div>
      </div>

      <div className="card" style={{ borderColor: "#F4B5B5" }}>
        <div className="card__head"><div className="card__title-lg" style={{ color: "#C13838" }}>{t.danger}</div></div>
        <div className="row-between">
          <div>
            <div style={{ fontSize: 14, fontWeight: 500 }}>{t.resetData}</div>
            <div className="text-xs muted">{t.resetDataSub}</div>
          </div>
          <button className="btn btn--outline" onClick={onReset} style={{ borderColor: "#F4B5B5", color: "#C13838" }}>
            {t.resetData}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ============================================================ */
/* ADD EXPENSE MODAL                                            */
/* ============================================================ */
function AddExpenseModal({ onClose, onSave, t, lang }) {
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [desc, setDesc] = useState("");
  const [overrideCat, setOverrideCat] = useState(null);

  const ai = useMemo(() => categorize(title, desc), [title, desc]);
  const finalCat = overrideCat || ai.category;
  const hasInput = title.trim().length > 0;

  function save(e) {
    e?.preventDefault();
    if (!title.trim() || !amount) return;
    onSave({
      title: title.trim(),
      amount: parseFloat(amount),
      date,
      description: desc.trim(),
      category: finalCat,
      aiConfidence: overrideCat ? 1.0 : ai.confidence,
    });
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal__head">
          <div>
            <div className="modal__title">{t.addTitle}</div>
            <div className="text-xs muted" style={{ marginTop: 2 }}>{t.addSub}</div>
          </div>
          <button className="icon-btn" onClick={onClose}><Icon name="x" size={16} /></button>
        </div>
        <form className="modal__body" onSubmit={save}>
          <div className="field">
            <label className="field__label">{t.fTitle}</label>
            <input className="input input--lg" placeholder={lang === "es" ? "Ej: Uber, Netflix, Starbucks..." : "e.g. Uber, Netflix, Starbucks..."}
              value={title} onChange={e => { setTitle(e.target.value); setOverrideCat(null); }} autoFocus />
          </div>
          <div className="row" style={{ gap: 12 }}>
            <div className="field" style={{ flex: 1 }}>
              <label className="field__label">{t.fAmount}</label>
              <div className="input-prefix">
                <span className="input-prefix__icon">$</span>
                <input className="input" type="number" step="0.01" placeholder="0.00"
                  value={amount} onChange={e => setAmount(e.target.value)} />
              </div>
            </div>
            <div className="field" style={{ flex: 1 }}>
              <label className="field__label">{t.fDate}</label>
              <input className="input" type="date" value={date} onChange={e => setDate(e.target.value)} />
            </div>
          </div>
          <div className="field">
            <label className="field__label">{t.fDesc}</label>
            <textarea className="textarea" placeholder={lang === "es" ? "Notas opcionales..." : "Optional notes..."}
              value={desc} onChange={e => { setDesc(e.target.value); setOverrideCat(null); }} />
          </div>

          {/* AI suggestion */}
          <div className="ai-suggest">
            {hasInput ? (
              <>
                <div className="ai-suggest__icon" style={{ background: `var(--c-${finalCat})` }}
                  dangerouslySetInnerHTML={{ __html: CAT_ICONS[finalCat] }} />
                <div>
                  <div className="ai-suggest__label">{t.aiSuggests}</div>
                  <div className="ai-suggest__cat">{t.cats[finalCat]}</div>
                </div>
                {ai.alternatives.length > 0 && (
                  <div className="ai-suggest__alt">
                    {ai.alternatives.slice(0, 2).map(c => (
                      <button key={c} type="button" className="ai-suggest__alt-chip" onClick={() => setOverrideCat(c)}>
                        <span className="chip__dot" style={{ background: `var(--c-${c})`, display: "inline-block", marginRight: 4 }}></span>
                        {t.cats[c]}
                      </button>
                    ))}
                  </div>
                )}
              </>
            ) : (
              <>
                <div className="ai-suggest__icon" style={{ background: "var(--violet-500)" }}>
                  <Icon name="sparkle" size={16} />
                </div>
                <div className="muted text-sm">{t.aiWaiting}</div>
              </>
            )}
          </div>
        </form>
        <div className="modal__foot">
          <button className="btn btn--ghost" onClick={onClose}>{t.cancel}</button>
          <button className="btn btn--primary" onClick={save} disabled={!title.trim() || !amount}>
            <Icon name="check" size={14} /> {t.save}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ============================================================ */
/* AUTH                                                         */
/* ============================================================ */
function AuthView({ onLogin, t, lang, setLang, theme, setTheme }) {
  const [mode, setMode] = useState("signin");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("sam@mira.app");
  const [password, setPassword] = useState("••••••••");

  function submit(e) {
    e.preventDefault();
    onLogin({
      name: mode === "signup" ? (name || "Sam Rivera") : "Sam Rivera",
      email: email || "sam@mira.app",
    });
  }

  return (
    <div className="auth-wrap">
      <div className="auth-form-side">
        <div style={{ position: "absolute", top: 20, right: 20, display: "flex", gap: 6 }}>
          <button className="icon-btn" onClick={() => setLang(lang === "en" ? "es" : "en")}>
            <span style={{ fontSize: 12, fontWeight: 600 }}>{lang.toUpperCase()}</span>
          </button>
          <button className="icon-btn" onClick={() => setTheme(theme === "light" ? "dark" : "light")}>
            <Icon name={theme === "light" ? "moon" : "sun"} size={16} />
          </button>
        </div>

        <form className="auth-form" onSubmit={submit}>
          <div className="auth-form__brand">
            <BrandLogo />
            <div>
              <div>{t.appName}</div>
              <div className="text-xs muted">{t.appTag}</div>
            </div>
          </div>

          <div className="auth-form__title">
            {mode === "signin" ? t.welcomeBack : t.createTitle}
          </div>
          <div className="auth-form__sub">
            {mode === "signin" ? t.signInSub : t.createSub}
          </div>

          <button type="button" className="btn btn--outline btn--lg btn--block" style={{ marginBottom: 18 }}>
            <Icon name="google" size={16} /> {t.continueGoogle}
          </button>

          <div style={{ display: "flex", alignItems: "center", gap: 12, margin: "8px 0 18px", color: "var(--text-faint)", fontSize: 12 }}>
            <div style={{ flex: 1, height: 1, background: "var(--border)" }}></div>
            <span>{t.or}</span>
            <div style={{ flex: 1, height: 1, background: "var(--border)" }}></div>
          </div>

          {mode === "signup" && (
            <div className="field">
              <label className="field__label">{t.name}</label>
              <input className="input input--lg" value={name} onChange={e => setName(e.target.value)} placeholder="Sam Rivera" />
            </div>
          )}
          <div className="field">
            <label className="field__label">{t.email_}</label>
            <input className="input input--lg" type="email" value={email} onChange={e => setEmail(e.target.value)} />
          </div>
          <div className="field">
            <label className="field__label">{t.password}</label>
            <input className="input input--lg" type="password" value={password} onChange={e => setPassword(e.target.value)} />
          </div>

          <button className="btn btn--primary btn--lg btn--block" type="submit" style={{ marginTop: 8 }}>
            {mode === "signin" ? t.signIn : t.signUp}
          </button>

          <div className="auth-form__foot">
            {mode === "signin" ? t.noAccount : t.haveAccount}{" "}
            <span className="link" onClick={() => setMode(mode === "signin" ? "signup" : "signin")}>
              {mode === "signin" ? t.signUp : t.signIn}
            </span>
          </div>
        </form>
      </div>
      <div className="auth-illus-side">
        <div className="auth-illus-side__quote">
          <div className="auth-illus-side__quote-mark">"</div>
          <div className="auth-illus-side__quote-text">{t.quote}</div>
          <div className="auth-illus-side__quote-by">— {t.quoteBy}</div>
        </div>
        {/* Decorative mock cards */}
        <div className="auth-mock-card" style={{ top: "10%", right: "8%", transform: "rotate(4deg)", width: 220 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <span className="text-xs muted">{lang === "es" ? "Este mes" : "This month"}</span>
            <span className="chip" style={{ background: "#DFF5E5", color: "#1F7A3F" }}>−12%</span>
          </div>
          <div style={{ fontSize: 24, fontWeight: 600, letterSpacing: "-0.02em" }}>$2,184.50</div>
          <div style={{ display: "flex", gap: 4, marginTop: 12 }}>
            {["var(--c-food)", "var(--c-transport)", "var(--c-subs)", "var(--c-shopping)", "var(--c-home)"].map((c, i) => (
              <div key={i} style={{ flex: [3, 2, 1.4, 1.2, 4][i], height: 6, background: c, borderRadius: 4 }}></div>
            ))}
          </div>
        </div>
        <div className="auth-mock-card" style={{ bottom: "12%", left: "6%", transform: "rotate(-3deg)", width: 240 }}>
          <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 8 }}>
            <div style={{ width: 28, height: 28, borderRadius: 8, background: "linear-gradient(135deg, var(--violet-400), var(--violet-600))", display: "grid", placeItems: "center", color: "white" }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3l1.9 5.8L20 11l-6.1 2.2L12 19l-1.9-5.8L4 11l6.1-2.2z"/></svg>
            </div>
            <span style={{ fontSize: 12, fontWeight: 600, color: "var(--violet-600)" }}>{"Mira AI"}</span>
          </div>
          <div style={{ fontSize: 13, lineHeight: 1.5 }}>
            {lang === "es"
              ? "Gastaste menos en Uber esta semana — ¡buen trabajo! 🎉"
              : "You spent less on Uber this week — nice work! 🎉"}
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  DashboardView, ExpensesView, InsightsView,
  CategoriesView, CategoryDetailView, SettingsView,
  AddExpenseModal, AuthView, ExpenseRow,
});
