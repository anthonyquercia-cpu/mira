/* Main App: auth + routing + state */
/* eslint-disable */
const TWEAK_DEFAULS = /*EDITMODE-BEGIN*/{
  "chartType": "donut"
}/*EDITMODE-END*/;

const STORAGE_KEY = "paa.state.v2";

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch { return null; }
}
function saveState(state) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch {}
}

function App() {
  const saved = loadState();
  const [authed, setAuthed] = useState(saved?.authed ?? false);
  const [user, setUser] = useState(saved?.user || { name: "Sam Rivera", email: "sam@mira.app" });
  const [expenses, setExpenses] = useState(saved?.expenses || window.PAA.SEED_EXPENSES);
  const [route, setRoute] = useState(saved?.route || "dashboard");
  const [activeCategory, setActiveCategory] = useState(null);
  const [theme, setTheme] = useState(saved?.theme || "light");
  const [lang, setLang] = useState(saved?.lang || "en");
  const [showAdd, setShowAdd] = useState(false);
  const [t_, setT_] = useTweaks(TWEAK_DEFAULS);

  const t = window.PAA.I18N[lang];

  // Persist
  useEffect(() => {
    saveState({ authed, user, expenses, route, theme, lang });
  }, [authed, user, expenses, route, theme, lang]);

  // Apply theme to document
  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    window.__themeKey = theme; // force chart redraws on theme change
  }, [theme]);

  function handleLogin(u) {
    setUser(u);
    setAuthed(true);
    setRoute("dashboard");
  }
  function handleLogout() {
    setAuthed(false);
  }
  function handleAdd(exp) {
    const newExp = { ...exp, id: Date.now() };
    setExpenses(prev => [newExp, ...prev]);
    setShowAdd(false);
  }
  function openCategory(cat) {
    setActiveCategory(cat);
    setRoute("category-detail");
  }
  function resetData() {
    setExpenses(window.PAA.SEED_EXPENSES);
  }

  if (!authed) {
    return <AuthView onLogin={handleLogin} t={t} lang={lang} setLang={setLang} theme={theme} setTheme={setTheme} />;
  }

  const titles = {
    dashboard:        { title: t.dashTitle,       sub: t.dashSub },
    expenses:         { title: t.expensesTitle,   sub: t.expensesSub },
    insights:         { title: t.insightsTitle,   sub: t.insightsSub },
    categories:       { title: t.nav.categories,  sub: lang === "es" ? "Tus gastos agrupados por tipo." : "Your expenses grouped by type." },
    "category-detail": activeCategory
      ? { title: t.cats[activeCategory], sub: lang === "es" ? "Detalle de categoría" : "Category detail" }
      : { title: t.nav.categories, sub: "" },
    settings:         { title: t.settingsTitle,   sub: t.settingsSub },
  };
  const meta = titles[route] || { title: "", sub: "" };

  return (
    <div className="app">
      <Sidebar route={route} setRoute={setRoute} user={user} t={t} onLogout={handleLogout} />
      <main className="main">
        <TopBar
          title={meta.title}
          subtitle={meta.sub}
          theme={theme} setTheme={setTheme}
          lang={lang} setLang={setLang}
          onAddExpense={() => setShowAdd(true)}
          showAdd={route !== "settings"}
          t={t}
        />
        {route === "dashboard" && (
          <DashboardView expenses={expenses} t={t} lang={lang} chartType={t_.chartType} setRoute={setRoute} openCategory={openCategory} />
        )}
        {route === "expenses" && (
          <ExpensesView expenses={expenses} t={t} lang={lang} />
        )}
        {route === "insights" && (
          <InsightsView expenses={expenses} t={t} lang={lang} />
        )}
        {route === "categories" && (
          <CategoriesView expenses={expenses} t={t} lang={lang} openCategory={openCategory} />
        )}
        {route === "category-detail" && activeCategory && (
          <CategoryDetailView category={activeCategory} expenses={expenses} t={t} lang={lang} setRoute={setRoute} />
        )}
        {route === "settings" && (
          <SettingsView t={t} lang={lang} setLang={setLang} theme={theme} setTheme={setTheme} user={user} onReset={resetData} />
        )}
      </main>

      {showAdd && (
        <AddExpenseModal onClose={() => setShowAdd(false)} onSave={handleAdd} t={t} lang={lang} />
      )}

      <TweaksPanel title="Tweaks">
        <TweakSection label={t.tweakChartType}>
          <TweakRadio
            label={t.tweakChartType}
            value={t_.chartType}
            onChange={(v) => setT_("chartType", v)}
            options={[
              { value: "donut", label: t.tweakDonut },
              { value: "bars",  label: t.tweakBars },
            ]}
          />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
