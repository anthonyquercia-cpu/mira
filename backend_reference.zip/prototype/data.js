/* ==========================================================================
   Personal AI Accountant — data, AI logic, i18n
   Exports to window.PAA so React components can pull from it.
   Wrapped in an IIFE so internal `const`s don't pollute the global scope and
   collide with the babel-transpiled scripts' top-level destructures.
   ========================================================================== */

(function () {

const CATEGORIES = [
  { id: "food",        emoji: "🍔", color: "var(--c-food)" },
  { id: "transport",   emoji: "🚗", color: "var(--c-transport)" },
  { id: "entertain",   emoji: "🎬", color: "var(--c-entertain)" },
  { id: "health",      emoji: "💊", color: "var(--c-health)" },
  { id: "subs",        emoji: "📺", color: "var(--c-subs)" },
  { id: "shopping",    emoji: "🛍️", color: "var(--c-shopping)" },
  { id: "home",        emoji: "🏠", color: "var(--c-home)" },
  { id: "other",       emoji: "💸", color: "var(--c-other)" },
];

const CAT_BY_ID = Object.fromEntries(CATEGORIES.map(c => [c.id, c]));

// Category icons — small inline SVGs so they look more refined than emoji
const CAT_ICONS = {
  food: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8h1a4 4 0 0 1 0 8h-1"/><path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"/><line x1="6" y1="2" x2="6" y2="4"/><line x1="10" y1="2" x2="10" y2="4"/><line x1="14" y1="2" x2="14" y2="4"/></svg>',
  transport: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 16H9m10 0h3v-3.15a1 1 0 0 0-.84-.99L16 11l-2.7-3.6a1 1 0 0 0-.8-.4H5.24a2 2 0 0 0-1.8 1.1l-.8 1.63A6 6 0 0 0 2 12.42V16h2"/><circle cx="6.5" cy="16.5" r="2.5"/><circle cx="16.5" cy="16.5" r="2.5"/></svg>',
  entertain: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>',
  health: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>',
  subs: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>',
  shopping: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>',
  home: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
  other: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>',
};

// --------------------------------------------------------------------------
// AI Categorizer — keyword-based (mirrors what would run in PHP)
// --------------------------------------------------------------------------
const KEYWORDS = {
  food: [
    "mcdonald", "mcdo", "starbucks", "burger", "pizza", "sushi", "tacos", "taco bell",
    "kfc", "subway", "chipotle", "wendy", "domino", "papa john", "dunkin", "tim hortons",
    "cafe", "café", "coffee", "restaurant", "restaurante", "comida", "almuerzo", "cena",
    "desayuno", "breakfast", "lunch", "dinner", "groceries", "supermercado", "walmart food",
    "kroger", "safeway", "whole foods", "trader joe", "costco food", "panaderia", "bakery",
    "doordash", "rappi", "ubereats", "uber eats", "didi food", "deli", "snack", "agua",
    "soda", "beer", "cerveza", "vino", "wine", "bar", "pub", "ipa"
  ],
  transport: [
    "uber", "lyft", "didi", "cabify", "taxi", "bolt", "gasolina", "gas", "fuel",
    "shell", "exxon", "mobil", "chevron", "bp ", "metro", "subway transit", "bus",
    "autobus", "tren", "train", "amtrak", "parking", "estacionamiento", "toll", "peaje",
    "aeropuerto", "airport", "vuelo", "flight", "airline", "delta", "united", "american airlines",
    "aeromexico", "avianca", "spirit", "southwest", "car wash", "lavado", "mecanico",
    "mechanic", "oil change", "tire", "llanta"
  ],
  entertain: [
    "cinepolis", "cinemex", "amc", "regal", "imax", "cinema", "movie", "pelicula",
    "concierto", "concert", "ticketmaster", "stubhub", "boleto", "ticket", "theater",
    "teatro", "museo", "museum", "bowling", "game", "spotify event", "festival",
    "club", "casino", "arcade", "minigolf", "park ticket", "disney park"
  ],
  health: [
    "pharmacy", "farmacia", "cvs", "walgreens", "rite aid", "doctor", "doctor visit",
    "clinic", "clinica", "hospital", "dentist", "dentista", "therapy", "therapist",
    "terapia", "gym", "gimnasio", "fitness", "yoga", "pilates", "vitamin", "vitamina",
    "medicine", "medicina", "medication", "lab", "laboratorio", "consulta"
  ],
  subs: [
    "netflix", "spotify", "apple music", "amazon prime", "hbo", "disney+", "disney plus",
    "hulu", "youtube premium", "youtube music", "icloud", "google one", "dropbox",
    "notion", "github", "openai", "chatgpt", "claude", "anthropic", "midjourney",
    "linkedin premium", "audible", "kindle", "patreon", "substack", "twitch", "paramount",
    "peacock", "discovery", "starz", "showtime", "crunchyroll", "duolingo", "headspace",
    "calm", "1password", "evernote", "figma", "adobe", "canva", "monthly subscription",
    "annual subscription", "renewal"
  ],
  shopping: [
    "amazon", "ebay", "etsy", "mercadolibre", "aliexpress", "shein", "zara", "h&m", "h and m",
    "uniqlo", "nike", "adidas", "apple store", "best buy", "target", "walmart", "macy",
    "nordstrom", "sephora", "ulta", "lego", "ikea purchase", "shop", "boutique", "store",
    "tienda", "online order", "pedido", "shopify"
  ],
  home: [
    "rent", "renta", "alquiler", "mortgage", "hipoteca", "electric", "electricidad", "luz",
    "water", "agua bill", "gas bill", "internet", "wifi", "comcast", "spectrum", "verizon",
    "at&t", "att", "t-mobile", "cellphone", "phone bill", "telefono", "ikea", "home depot",
    "lowes", "furniture", "muebles", "cleaning", "limpieza", "hoa", "condo", "apartment",
    "household", "casa"
  ],
};

// Confidence + alternatives — returns { category, confidence, alternatives }
function categorize(title = "", description = "") {
  const text = (title + " " + description).toLowerCase().trim();
  if (!text) return { category: "other", confidence: 0, alternatives: [] };

  const scores = {};
  for (const cat in KEYWORDS) {
    scores[cat] = 0;
    for (const kw of KEYWORDS[cat]) {
      if (text.includes(kw)) {
        // Longer keywords are more specific → higher score
        scores[cat] += Math.max(1, Math.floor(kw.length / 3));
      }
    }
  }

  const ranked = Object.entries(scores).sort((a, b) => b[1] - a[1]);
  const [topCat, topScore] = ranked[0];
  if (topScore === 0) return { category: "other", confidence: 0, alternatives: [] };

  const total = ranked.reduce((s, [, v]) => s + v, 0);
  const confidence = Math.min(0.99, 0.5 + (topScore / Math.max(total, topScore)) * 0.5);

  const alternatives = ranked
    .slice(1, 4)
    .filter(([, s]) => s > 0)
    .map(([c]) => c);

  return { category: topCat, confidence, alternatives };
}

// --------------------------------------------------------------------------
// AI Insights — friendly motivational coach
// --------------------------------------------------------------------------
function generateInsights(expenses, lang = "en") {
  const t = I18N[lang];
  if (!expenses.length) {
    return [{
      tone: "neutral",
      title: t.insightWelcomeTitle,
      body: t.insightWelcomeBody,
      icon: "sparkle",
    }];
  }

  const now = new Date();
  const thisMonth = expenses.filter(e => {
    const d = new Date(e.date);
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  });
  const lastMonth = expenses.filter(e => {
    const d = new Date(e.date);
    const lm = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    return d.getMonth() === lm.getMonth() && d.getFullYear() === lm.getFullYear();
  });

  const totalThis = sum(thisMonth);
  const totalLast = sum(lastMonth);
  const byCat = groupByCategory(thisMonth);
  const byCatLast = groupByCategory(lastMonth);
  const topCat = Object.entries(byCat).sort((a, b) => b[1] - a[1])[0];

  const insights = [];

  // 1. Top category callout (always present if there's data)
  if (topCat) {
    const [cat, amt] = topCat;
    const catName = t.cats[cat];
    const pct = totalThis ? Math.round((amt / totalThis) * 100) : 0;
    insights.push({
      tone: "coach",
      title: t.insightTopCatTitle.replace("{cat}", catName),
      body: t.insightTopCatBody
        .replace("{amt}", formatMoney(amt))
        .replace("{pct}", pct)
        .replace("{cat}", catName.toLowerCase()),
      icon: "trophy",
      cat,
    });
  }

  // 2. Category increases month over month
  for (const cat in byCat) {
    const a = byCat[cat], b = byCatLast[cat] || 0;
    if (b > 0 && a > b * 1.3 && a - b > 30) {
      const delta = Math.round(((a - b) / b) * 100);
      insights.push({
        tone: "warn",
        title: t.insightSpikeTitle.replace("{cat}", t.cats[cat]),
        body: t.insightSpikeBody
          .replace("{cat}", t.cats[cat].toLowerCase())
          .replace("{pct}", delta)
          .replace("{diff}", formatMoney(a - b)),
        icon: "arrow-up",
        cat,
      });
      break;
    }
  }

  // 3. Subscriptions warning
  const subsAmt = byCat.subs || 0;
  if (subsAmt > 0) {
    if (subsAmt > totalThis * 0.2) {
      insights.push({
        tone: "warn",
        title: t.insightSubsTitle,
        body: t.insightSubsBody.replace("{amt}", formatMoney(subsAmt)),
        icon: "tv",
        cat: "subs",
      });
    }
  }

  // 4. Win — a category that went down
  for (const cat in byCatLast) {
    const a = byCat[cat] || 0, b = byCatLast[cat];
    if (b > 40 && a < b * 0.7) {
      insights.push({
        tone: "win",
        title: t.insightWinTitle.replace("{cat}", t.cats[cat]),
        body: t.insightWinBody
          .replace("{amt}", formatMoney(b - a))
          .replace("{cat}", t.cats[cat].toLowerCase()),
        icon: "trending-down",
        cat,
      });
      break;
    }
  }

  // 5. Coach nudge — based on total
  if (totalLast > 0) {
    if (totalThis > totalLast * 1.15) {
      insights.push({
        tone: "warn",
        title: t.insightPaceTitle,
        body: t.insightPaceUpBody
          .replace("{pct}", Math.round(((totalThis - totalLast) / totalLast) * 100))
          .replace("{diff}", formatMoney(totalThis - totalLast)),
        icon: "trending-up",
      });
    } else if (totalThis < totalLast * 0.85) {
      insights.push({
        tone: "win",
        title: t.insightPaceDownTitle,
        body: t.insightPaceDownBody.replace("{diff}", formatMoney(totalLast - totalThis)),
        icon: "trending-down",
      });
    }
  }

  // 6. Daily average + projection
  const day = now.getDate();
  const avgPerDay = totalThis / day;
  const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  const projected = avgPerDay * daysInMonth;
  if (totalThis > 0 && day >= 5) {
    insights.push({
      tone: "neutral",
      title: t.insightProjectTitle,
      body: t.insightProjectBody
        .replace("{avg}", formatMoney(avgPerDay))
        .replace("{proj}", formatMoney(projected)),
      icon: "calendar",
    });
  }

  return insights;
}

// Brief 1-2 line AI summary for the dashboard hero
function dashboardSummary(expenses, lang = "en") {
  const t = I18N[lang];
  if (!expenses.length) return t.aiSumEmpty;

  const now = new Date();
  const thisMonth = expenses.filter(e => sameMonth(new Date(e.date), now));
  const total = sum(thisMonth);
  if (total === 0) return t.aiSumEmpty;

  const byCat = groupByCategory(thisMonth);
  const topCat = Object.entries(byCat).sort((a, b) => b[1] - a[1])[0];
  if (!topCat) return t.aiSumEmpty;

  const [cat, amt] = topCat;
  const day = now.getDate();
  const avg = total / day;
  const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  const projected = avg * daysInMonth;

  return t.aiSumLine
    .replace("{total}", formatMoney(total))
    .replace("{cat}", t.cats[cat].toLowerCase())
    .replace("{catAmt}", formatMoney(amt))
    .replace("{proj}", formatMoney(projected));
}

// --------------------------------------------------------------------------
// Utilities
// --------------------------------------------------------------------------
const sum = (arr) => arr.reduce((s, e) => s + Number(e.amount || 0), 0);
const sameMonth = (a, b) => a.getMonth() === b.getMonth() && a.getFullYear() === b.getFullYear();
const groupByCategory = (arr) => {
  const out = {};
  for (const e of arr) out[e.category] = (out[e.category] || 0) + Number(e.amount);
  return out;
};
const formatMoney = (n, currency = "$") =>
  currency + Number(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const formatDate = (d, lang = "en") => {
  const date = new Date(d);
  return date.toLocaleDateString(lang === "es" ? "es-MX" : "en-US",
    { month: "short", day: "numeric" });
};
const formatDateLong = (d, lang = "en") => {
  const date = new Date(d);
  return date.toLocaleDateString(lang === "es" ? "es-MX" : "en-US",
    { year: "numeric", month: "long", day: "numeric" });
};

// --------------------------------------------------------------------------
// Seed data — small, realistic, this-month-heavy
// --------------------------------------------------------------------------
function todayMinus(days) {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d.toISOString().slice(0, 10);
}
function lastMonthDay(day) {
  const d = new Date();
  d.setMonth(d.getMonth() - 1);
  d.setDate(day);
  return d.toISOString().slice(0, 10);
}

const SEED_EXPENSES = [
  // This month
  { id: 1,  title: "Uber",              amount: 14.20, date: todayMinus(0),  description: "ride to office", category: "transport", aiConfidence: 0.95 },
  { id: 2,  title: "Starbucks",         amount: 6.75,  date: todayMinus(0),  description: "morning cold brew", category: "food", aiConfidence: 0.92 },
  { id: 3,  title: "Spotify",           amount: 11.99, date: todayMinus(1),  description: "monthly", category: "subs", aiConfidence: 0.98 },
  { id: 4,  title: "Whole Foods",       amount: 87.40, date: todayMinus(2),  description: "weekly groceries", category: "food", aiConfidence: 0.88 },
  { id: 5,  title: "Netflix",           amount: 17.99, date: todayMinus(3),  description: "", category: "subs", aiConfidence: 0.99 },
  { id: 6,  title: "Cinepolis",         amount: 24.50, date: todayMinus(4),  description: "Dune Part II tickets", category: "entertain", aiConfidence: 0.93 },
  { id: 7,  title: "Shell",             amount: 52.10, date: todayMinus(5),  description: "tank fill", category: "transport", aiConfidence: 0.91 },
  { id: 8,  title: "Amazon",            amount: 42.99, date: todayMinus(6),  description: "kitchen items", category: "shopping", aiConfidence: 0.86 },
  { id: 9,  title: "CVS Pharmacy",      amount: 18.30, date: todayMinus(8),  description: "allergy meds", category: "health", aiConfidence: 0.94 },
  { id: 10, title: "Chipotle",          amount: 13.45, date: todayMinus(9),  description: "burrito bowl", category: "food", aiConfidence: 0.95 },
  // Last month
  { id: 11, title: "Rent",              amount: 1450.00, date: lastMonthDay(1),  description: "apartment", category: "home", aiConfidence: 0.97 },
  { id: 12, title: "Netflix",           amount: 17.99, date: lastMonthDay(3),  description: "", category: "subs", aiConfidence: 0.99 },
  { id: 13, title: "Spotify",           amount: 11.99, date: lastMonthDay(1),  description: "", category: "subs", aiConfidence: 0.98 },
  { id: 14, title: "Shell",             amount: 48.20, date: lastMonthDay(7),  description: "", category: "transport", aiConfidence: 0.91 },
  { id: 15, title: "Whole Foods",       amount: 102.30, date: lastMonthDay(10), description: "", category: "food", aiConfidence: 0.88 },
  { id: 16, title: "Uber",              amount: 22.50, date: lastMonthDay(12), description: "", category: "transport", aiConfidence: 0.95 },
];

// --------------------------------------------------------------------------
// i18n
// --------------------------------------------------------------------------
const I18N = {
  en: {
    locale: "en-US",
    appName: "Mira",
    appTag: "AI money coach",
    nav: {
      dashboard: "Dashboard",
      expenses: "Expenses",
      insights: "Insights",
      categories: "Categories",
      settings: "Settings",
    },
    navSec: { main: "Overview", manage: "Manage" },
    cats: {
      food: "Food & Drink",
      transport: "Transport",
      entertain: "Entertainment",
      health: "Health",
      subs: "Subscriptions",
      shopping: "Shopping",
      home: "Home & Bills",
      other: "Other",
    },
    // Dashboard
    dashTitle: "Hey Sam 👋",
    dashSub: "Here's how your money is moving this month.",
    statMonthTotal: "Spent this month",
    statTransactions: "Transactions",
    statTopCat: "Top category",
    statAvgDay: "Avg per day",
    vsLast: "vs. last month",
    aiSumEmpty: "Add your first expense and I'll start finding patterns for you.",
    aiSumLine: "You've spent {total} so far this month — {cat} is leading at {catAmt}. At this pace you'll land around {proj}. Let's keep that in check 💪",
    sectionByCat: "By category",
    sectionMonthly: "Monthly trend",
    sectionRecent: "Recent expenses",
    seeAll: "See all",
    addExpense: "Add expense",
    // Insights
    insightsTitle: "Your AI Insights",
    insightsSub: "Personal observations and nudges based on your spending.",
    insightWelcomeTitle: "Welcome to Mira!",
    insightWelcomeBody: "Add your first few expenses and I'll start spotting patterns and helping you save.",
    insightTopCatTitle: "{cat} is your biggest spend",
    insightTopCatBody: "You've put {amt} into {cat} — that's {pct}% of this month. Worth knowing where it's going.",
    insightSpikeTitle: "Heads up: {cat} jumped",
    insightSpikeBody: "Spending in {cat} is up {pct}% vs last month (+{diff}). Anything one-off, or a new habit forming?",
    insightSubsTitle: "Subscriptions are stacking up",
    insightSubsBody: "You're paying {amt} in subscriptions this month. Want to audit them together?",
    insightWinTitle: "Nice work on {cat} 🎉",
    insightWinBody: "You cut {cat} by {amt} compared to last month. Real savings — keep it going.",
    insightPaceTitle: "You're spending faster",
    insightPaceUpBody: "Overall spend is up {pct}% from last month (+{diff}). Let's slow it down a notch this week.",
    insightPaceDownTitle: "Slower month, well done",
    insightPaceDownBody: "You're {diff} under last month's pace. That's money staying in your pocket.",
    insightProjectTitle: "End-of-month projection",
    insightProjectBody: "Averaging {avg}/day. If you keep this pace you'll close the month around {proj}.",
    // Expenses page
    expensesTitle: "Expenses",
    expensesSub: "Every transaction, categorized by AI.",
    search: "Search by title, description...",
    all: "All",
    thisMonth: "This month",
    lastMonth: "Last month",
    last3: "Last 3 months",
    allTime: "All time",
    noResults: "No expenses match those filters.",
    // Add modal
    addTitle: "Add expense",
    addSub: "AI will categorize it automatically",
    fTitle: "Title",
    fAmount: "Amount",
    fDate: "Date",
    fDesc: "Description (optional)",
    aiSuggests: "AI suggests",
    aiAlternative: "Or:",
    aiWaiting: "Type a title and I'll categorize it...",
    cancel: "Cancel",
    save: "Save expense",
    // Category detail
    backTo: "Back to",
    catTotalThis: "This month",
    catTotalAvg: "Monthly average",
    catCount: "Transactions",
    // Settings
    settingsTitle: "Settings",
    settingsSub: "Tweak the basics.",
    appearance: "Appearance",
    darkMode: "Dark mode",
    language: "Language",
    currency: "Currency",
    profile: "Profile",
    name: "Name",
    email: "Email",
    danger: "Danger zone",
    resetData: "Reset to demo data",
    resetDataSub: "Restore the sample expenses. Useful for trying the demo again.",
    // Auth
    welcomeBack: "Welcome back",
    signInSub: "Sign in to keep building good money habits.",
    createTitle: "Create your account",
    createSub: "Start tracking expenses in 30 seconds.",
    email_: "Email",
    password: "Password",
    signIn: "Sign in",
    signUp: "Create account",
    noAccount: "Don't have an account?",
    haveAccount: "Already have an account?",
    quote: "Mira finally made me understand where my money goes — without a spreadsheet.",
    quoteBy: "Sofia, designer in Brooklyn",
    or: "or",
    continueGoogle: "Continue with Google",
    // Tweaks
    tweakChartType: "Main chart style",
    tweakDonut: "Donut",
    tweakBars: "Bars",
    tweakArea: "Area",
  },
  es: {
    locale: "es-MX",
    appName: "Mira",
    appTag: "tu coach con IA",
    nav: {
      dashboard: "Panel",
      expenses: "Gastos",
      insights: "Insights",
      categories: "Categorías",
      settings: "Ajustes",
    },
    navSec: { main: "Resumen", manage: "Gestión" },
    cats: {
      food: "Comida y bebida",
      transport: "Transporte",
      entertain: "Entretenimiento",
      health: "Salud",
      subs: "Suscripciones",
      shopping: "Compras",
      home: "Hogar y servicios",
      other: "Otros",
    },
    dashTitle: "Hola Sam 👋",
    dashSub: "Así se mueve tu dinero este mes.",
    statMonthTotal: "Gastado este mes",
    statTransactions: "Transacciones",
    statTopCat: "Categoría principal",
    statAvgDay: "Promedio diario",
    vsLast: "vs. mes anterior",
    aiSumEmpty: "Agrega tu primer gasto y empiezo a encontrar patrones para ti.",
    aiSumLine: "Llevas {total} este mes — {cat} va al frente con {catAmt}. A este ritmo cerrarías cerca de {proj}. Mantengámoslo a raya 💪",
    sectionByCat: "Por categoría",
    sectionMonthly: "Tendencia mensual",
    sectionRecent: "Gastos recientes",
    seeAll: "Ver todos",
    addExpense: "Agregar gasto",
    insightsTitle: "Tus insights de IA",
    insightsSub: "Observaciones personales basadas en tu forma de gastar.",
    insightWelcomeTitle: "¡Bienvenido a Mira!",
    insightWelcomeBody: "Agrega tus primeros gastos y empezaré a detectar patrones y ayudarte a ahorrar.",
    insightTopCatTitle: "{cat} es tu mayor gasto",
    insightTopCatBody: "Llevas {amt} en {cat} — eso es el {pct}% del mes. Vale la pena saber a dónde va.",
    insightSpikeTitle: "Ojo: {cat} subió",
    insightSpikeBody: "Tu gasto en {cat} subió {pct}% vs el mes pasado (+{diff}). ¿Algo puntual o un nuevo hábito?",
    insightSubsTitle: "Tus suscripciones se acumulan",
    insightSubsBody: "Estás pagando {amt} en suscripciones este mes. ¿Las revisamos juntos?",
    insightWinTitle: "¡Buen trabajo en {cat}! 🎉",
    insightWinBody: "Bajaste {cat} en {amt} comparado con el mes pasado. Eso es ahorro real — sigue así.",
    insightPaceTitle: "Estás gastando más rápido",
    insightPaceUpBody: "Tu gasto total subió {pct}% vs el mes pasado (+{diff}). Bajemos un poco el ritmo esta semana.",
    insightPaceDownTitle: "Mes más tranquilo, bien hecho",
    insightPaceDownBody: "Vas {diff} por debajo del ritmo del mes pasado. Ese dinero se queda contigo.",
    insightProjectTitle: "Proyección de fin de mes",
    insightProjectBody: "Promedias {avg}/día. Si mantienes el ritmo cerrarás el mes cerca de {proj}.",
    expensesTitle: "Gastos",
    expensesSub: "Cada transacción, categorizada por IA.",
    search: "Buscar por título, descripción...",
    all: "Todos",
    thisMonth: "Este mes",
    lastMonth: "Mes pasado",
    last3: "Últimos 3 meses",
    allTime: "Todo el tiempo",
    noResults: "Ningún gasto coincide con los filtros.",
    addTitle: "Agregar gasto",
    addSub: "La IA lo categoriza automáticamente",
    fTitle: "Título",
    fAmount: "Monto",
    fDate: "Fecha",
    fDesc: "Descripción (opcional)",
    aiSuggests: "La IA sugiere",
    aiAlternative: "O:",
    aiWaiting: "Escribe un título y lo categorizo...",
    cancel: "Cancelar",
    save: "Guardar gasto",
    backTo: "Volver a",
    catTotalThis: "Este mes",
    catTotalAvg: "Promedio mensual",
    catCount: "Transacciones",
    settingsTitle: "Ajustes",
    settingsSub: "Configura lo básico.",
    appearance: "Apariencia",
    darkMode: "Modo oscuro",
    language: "Idioma",
    currency: "Moneda",
    profile: "Perfil",
    name: "Nombre",
    email: "Correo",
    danger: "Zona peligrosa",
    resetData: "Restaurar datos de demo",
    resetDataSub: "Recupera los gastos de ejemplo. Útil para probar la demo otra vez.",
    welcomeBack: "Bienvenido de nuevo",
    signInSub: "Inicia sesión y sigue construyendo buenos hábitos.",
    createTitle: "Crea tu cuenta",
    createSub: "Empieza a registrar gastos en 30 segundos.",
    email_: "Correo",
    password: "Contraseña",
    signIn: "Iniciar sesión",
    signUp: "Crear cuenta",
    noAccount: "¿No tienes cuenta?",
    haveAccount: "¿Ya tienes cuenta?",
    quote: "Mira por fin me hizo entender a dónde va mi dinero — sin hojas de cálculo.",
    quoteBy: "Sofía, diseñadora en CDMX",
    or: "o",
    continueGoogle: "Continuar con Google",
    tweakChartType: "Estilo del gráfico principal",
    tweakDonut: "Dona",
    tweakBars: "Barras",
    tweakArea: "Área",
  },
};

window.PAA = {
  CATEGORIES, CAT_BY_ID, CAT_ICONS, KEYWORDS,
  categorize, generateInsights, dashboardSummary,
  sum, sameMonth, groupByCategory, formatMoney, formatDate, formatDateLong,
  SEED_EXPENSES, I18N,
};

})();
