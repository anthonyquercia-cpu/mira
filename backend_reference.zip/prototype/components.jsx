/* Shared atoms + chrome: Sidebar, TopBar, Icon, CategoryDot, charts wrapper */
/* eslint-disable */
const { useState, useEffect, useRef, useMemo, useCallback } = React;
const { CATEGORIES, CAT_BY_ID, CAT_ICONS, formatMoney, formatDate, sum, groupByCategory } = window.PAA;

/* --- Lucide-style icons (inline SVG, stroke 2) --- */
function Icon({ name, size = 18, className = "" }) {
  const paths = {
    dashboard: <path d="M3 13h8V3H3zM13 21h8V11h-8zM3 21h8v-6H3zM13 3v6h8V3z" />,
    list: <><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></>,
    sparkle: <><path d="M12 3l1.9 5.8L20 11l-6.1 2.2L12 19l-1.9-5.8L4 11l6.1-2.2z"/></>,
    grid: <><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></>,
    settings: <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h0a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h0a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v0a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></>,
    plus: <><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></>,
    search: <><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></>,
    arrowLeft: <><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></>,
    arrowUp: <><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></>,
    arrowDown: <><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></>,
    trendUp: <><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></>,
    trendDown: <><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/></>,
    trophy: <><path d="M6 9H4a2 2 0 0 1-2-2V6a1 1 0 0 1 1-1h3"/><path d="M18 9h2a2 2 0 0 0 2-2V6a1 1 0 0 0-1-1h-3"/><path d="M6 9V5a3 3 0 0 1 3-3h6a3 3 0 0 1 3 3v4a6 6 0 0 1-12 0z"/><line x1="12" y1="15" x2="12" y2="22"/><line x1="8" y1="22" x2="16" y2="22"/></>,
    tv: <><rect x="2" y="7" width="20" height="15" rx="2" ry="2"/><polyline points="17 2 12 7 7 2"/></>,
    calendar: <><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></>,
    bell: <><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></>,
    sun: <><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></>,
    moon: <><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></>,
    x: <><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></>,
    globe: <><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></>,
    chevronRight: <polyline points="9 18 15 12 9 6"/>,
    logout: <><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></>,
    check: <polyline points="20 6 9 17 4 12"/>,
    inbox: <><polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/></>,
    google: <><path d="M21.35 11.1H12v3.2h5.35c-.23 1.2-.93 2.22-1.97 2.9v2.4h3.18c1.86-1.72 2.94-4.25 2.94-7.25 0-.7-.07-1.37-.18-2.05z"/><path d="M12 21c2.65 0 4.88-.88 6.5-2.4l-3.18-2.4c-.88.6-2 .95-3.32.95-2.55 0-4.71-1.72-5.48-4.04H3.25v2.48A9 9 0 0 0 12 21z"/><path d="M6.52 13.1A5.4 5.4 0 0 1 6.25 12c0-.38.07-.75.13-1.1V8.42H3.25A9 9 0 0 0 3 12c0 1.45.35 2.83.97 4.04z"/><path d="M12 5.96c1.44 0 2.73.5 3.75 1.46l2.82-2.82C16.88 2.99 14.65 2 12 2A9 9 0 0 0 3.25 8.42L6.52 10.9C7.29 8.58 9.45 5.96 12 5.96z"/></>,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24"
      fill="none" stroke="currentColor" strokeWidth="2"
      strokeLinecap="round" strokeLinejoin="round" className={className}>
      {paths[name] || null}
    </svg>
  );
}

/* CategoryDot — colored square with icon, used in expense rows */
function CategoryDot({ cat, size = 36 }) {
  const c = CAT_BY_ID[cat] || CAT_BY_ID.other;
  // We hex-tint background using the CSS var color at low opacity
  return (
    <span className="cat-dot"
      style={{ width: size, height: size, background: `color-mix(in oklab, ${c.color} 18%, transparent)`, color: c.color }}
      dangerouslySetInnerHTML={{ __html: CAT_ICONS[c.id] || CAT_ICONS.other }} />
  );
}

/* Brand logo — abstract aperture/eye that nods to "Mira" (look) */
function BrandLogo({ size = 32 }) {
  return (
    <span className="sidebar__brand-logo" style={{ width: size, height: size, borderRadius: Math.round(size / 3) }}>
      <svg width={size * 0.58} height={size * 0.58} viewBox="0 0 24 24" fill="none">
        {/* outer iris ring */}
        <circle cx="12" cy="12" r="9" stroke="rgba(255,255,255,0.55)" strokeWidth="1.8" fill="none"/>
        {/* pupil */}
        <circle cx="12" cy="12" r="4.2" fill="white"/>
        {/* highlight catch-light */}
        <circle cx="14" cy="10" r="1.1" fill="#6C4CF2"/>
      </svg>
    </span>
  );
}

/* ---------- Sidebar ---------- */
function Sidebar({ route, setRoute, user, t, onLogout }) {
  const items = [
    { id: "dashboard", icon: "dashboard", label: t.nav.dashboard, section: "main" },
    { id: "expenses",  icon: "list",      label: t.nav.expenses,  section: "main" },
    { id: "insights",  icon: "sparkle",   label: t.nav.insights,  section: "main" },
    { id: "categories", icon: "grid",     label: t.nav.categories, section: "manage" },
    { id: "settings",  icon: "settings",  label: t.nav.settings,  section: "manage" },
  ];

  return (
    <aside className="sidebar">
      <div className="sidebar__brand">
        <BrandLogo />
        <div>
          <div>{t.appName}</div>
          <div className="sidebar__brand-sub">{t.appTag}</div>
        </div>
      </div>

      <div className="nav-section-label">{t.navSec.main}</div>
      {items.filter(i => i.section === "main").map(it => (
        <button key={it.id}
          className={"nav-item " + (route === it.id ? "is-active" : "")}
          onClick={() => setRoute(it.id)}>
          <Icon name={it.icon} size={18} />
          {it.label}
        </button>
      ))}

      <div className="nav-section-label">{t.navSec.manage}</div>
      {items.filter(i => i.section === "manage").map(it => (
        <button key={it.id}
          className={"nav-item " + (route === it.id ? "is-active" : "")}
          onClick={() => setRoute(it.id)}>
          <Icon name={it.icon} size={18} />
          {it.label}
        </button>
      ))}

      <div className="sidebar__footer">
        <span className="avatar">{(user?.name || "S")[0].toUpperCase()}</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13, fontWeight: 500, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{user?.name || "Sam Rivera"}</div>
          <div className="text-xs muted" style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{user?.email || "sam@mira.app"}</div>
        </div>
        <button className="icon-btn" onClick={onLogout} title="Sign out">
          <Icon name="logout" size={16} />
        </button>
      </div>
    </aside>
  );
}

/* ---------- Top bar ---------- */
function TopBar({ title, subtitle, theme, setTheme, lang, setLang, onAddExpense, showAdd = true, t }) {
  return (
    <header className="topbar">
      <div>
        <div className="topbar__title">{title}</div>
        {subtitle && <div className="topbar__subtitle">{subtitle}</div>}
      </div>
      <div className="row" style={{ gap: 6 }}>
        <button className="icon-btn" onClick={() => setLang(lang === "en" ? "es" : "en")} title={lang === "en" ? "Español" : "English"}>
          <span style={{ fontSize: 12, fontWeight: 600 }}>{lang.toUpperCase()}</span>
        </button>
        <button className="icon-btn" onClick={() => setTheme(theme === "light" ? "dark" : "light")} title="Toggle theme">
          <Icon name={theme === "light" ? "moon" : "sun"} size={16} />
        </button>
        <button className="icon-btn">
          <Icon name="bell" size={16} />
        </button>
        {showAdd && (
          <button className="btn btn--primary" onClick={onAddExpense} style={{ marginLeft: 6 }}>
            <Icon name="plus" size={16} /> {t.addExpense}
          </button>
        )}
      </div>
    </header>
  );
}

/* ---------- Charts (Chart.js) ---------- */
function useChart(ref, config, deps) {
  useEffect(() => {
    if (!ref.current) return;
    const chart = new Chart(ref.current, config);
    return () => chart.destroy();
  }, deps);
}

function readVar(name) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

function CategoryChart({ expenses, t, mode = "donut", themeKey }) {
  const ref = useRef(null);
  const data = useMemo(() => {
    const grouped = groupByCategory(expenses);
    const order = Object.entries(grouped).sort((a, b) => b[1] - a[1]);
    return {
      labels: order.map(([c]) => t.cats[c]),
      values: order.map(([, v]) => v),
      colors: order.map(([c]) => readVar(`--c-${c === "entertain" ? "entertain" : c}`)),
      cats:   order.map(([c]) => c),
    };
  }, [expenses, t, themeKey]);

  useChart(ref, {
    type: mode === "bars" ? "bar" : "doughnut",
    data: {
      labels: data.labels,
      datasets: [{
        data: data.values,
        backgroundColor: data.colors,
        borderColor: mode === "bars" ? data.colors : readVar("--bg-elev"),
        borderWidth: mode === "bars" ? 0 : 3,
        borderRadius: mode === "bars" ? 8 : 0,
        hoverOffset: 6,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: mode === "donut" ? "68%" : undefined,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: readVar("--text"),
          titleColor: readVar("--bg-elev"),
          bodyColor: readVar("--bg-elev"),
          padding: 10, cornerRadius: 8, displayColors: false,
          callbacks: { label: (ctx) => formatMoney(ctx.parsed.y ?? ctx.parsed) },
        },
      },
      scales: mode === "bars" ? {
        x: { grid: { display: false }, ticks: { color: readVar("--text-muted"), font: { size: 11 } } },
        y: { grid: { color: readVar("--border") }, ticks: { color: readVar("--text-muted"), font: { size: 11 }, callback: v => "$" + v } },
      } : {},
    },
  }, [expenses, mode, themeKey, t]);

  return <canvas ref={ref}></canvas>;
}

/* Monthly bars: last 6 months total */
function MonthlyChart({ expenses, lang, themeKey, mode = "bars" }) {
  const ref = useRef(null);
  const series = useMemo(() => {
    const now = new Date();
    const months = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      months.push({ d, label: d.toLocaleDateString(lang === "es" ? "es-MX" : "en-US", { month: "short" }), total: 0 });
    }
    for (const e of expenses) {
      const ed = new Date(e.date);
      const m = months.find(m => m.d.getMonth() === ed.getMonth() && m.d.getFullYear() === ed.getFullYear());
      if (m) m.total += Number(e.amount);
    }
    return months;
  }, [expenses, lang]);

  useChart(ref, {
    type: mode === "area" ? "line" : "bar",
    data: {
      labels: series.map(s => s.label),
      datasets: [{
        data: series.map(s => Math.round(s.total)),
        backgroundColor: mode === "area" ? "rgba(108, 76, 242, 0.12)" : readVar("--violet-500"),
        borderColor: readVar("--violet-500"),
        borderWidth: mode === "area" ? 2 : 0,
        borderRadius: 8,
        fill: mode === "area",
        tension: 0.35,
        pointBackgroundColor: readVar("--violet-500"),
        pointRadius: mode === "area" ? 3 : 0,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: readVar("--text"),
          titleColor: readVar("--bg-elev"),
          bodyColor: readVar("--bg-elev"),
          padding: 10, cornerRadius: 8, displayColors: false,
          callbacks: { label: (ctx) => formatMoney(ctx.parsed.y) },
        },
      },
      scales: {
        x: { grid: { display: false }, ticks: { color: readVar("--text-muted"), font: { size: 11 } } },
        y: { grid: { color: readVar("--border") }, ticks: { color: readVar("--text-muted"), font: { size: 11 }, callback: v => "$" + v }, beginAtZero: true },
      },
    },
  }, [expenses, lang, themeKey, mode]);

  return <canvas ref={ref}></canvas>;
}

/* Single donut for the "today" center label */
function DonutCenter({ total }) {
  return (
    <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center", pointerEvents: "none" }}>
      <div style={{ textAlign: "center" }}>
        <div className="text-xs muted">Total</div>
        <div style={{ fontSize: 22, fontWeight: 600, letterSpacing: "-0.02em", marginTop: 2 }}>
          {formatMoney(total)}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  Icon, CategoryDot, BrandLogo, Sidebar, TopBar,
  CategoryChart, MonthlyChart, DonutCenter,
});
